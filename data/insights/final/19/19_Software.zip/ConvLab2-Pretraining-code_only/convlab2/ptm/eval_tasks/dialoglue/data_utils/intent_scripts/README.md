All these scripts are adapted from the original PolyAI intent classification data downloads that used to be kept here: https://github.com/PolyAI-LDN/polyai-models.

They are maintained as is from the original source to ensure experimental consistency.
