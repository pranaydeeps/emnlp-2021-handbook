import os

from convlab2 import get_root_path

DATA_PTM_PATH = os.path.join(get_root_path(), 'data_ptm')
