set -e

bash run_woz.sh

bash run_simm.sh


bash run_simr.sh