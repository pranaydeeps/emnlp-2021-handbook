import json
import logging
import math
import os
import random
import re
import copy
import shutil
import glob
import collections
from collections import defaultdict
from contextlib import contextmanager
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
# from packaging import version
from torch import nn
from torch.utils.data.dataloader import DataLoader
from torch.utils.data.dataset import Dataset
from torch.utils.data.distributed import DistributedSampler
from torch.utils.data.sampler import RandomSampler, Sampler, SequentialSampler
from tqdm import tqdm, trange

from convlab2.ptm.pretraining.model.modeling_utils import PreTrainedModel
from convlab2.ptm.pretraining.model.optimization import AdamW, get_linear_schedule_with_warmup, get_constant_schedule_with_warmup, get_stair_schedule_with_warmup
from convlab2.ptm.pretraining.model.trainer_utils import PREFIX_CHECKPOINT_DIR, EvalPrediction, PredictionOutput, TrainOutput
from convlab2.ptm.pretraining.model.training_args import ModelArguments, DataTrainingArguments, TrainingArguments, is_tpu_available
from convlab2.ptm.pretraining.dataloader import MetaDataloader
from convlab2.ptm.pretraining.model import DialogBertTokenizer


try:
    from apex import amp

    _has_apex = True
except ImportError:
    _has_apex = False


def is_apex_available():
    return _has_apex


if is_tpu_available():
    import torch_xla.core.xla_model as xm
    import torch_xla.debug.metrics as met
    import torch_xla.distributed.parallel_loader as pl

try:
    from torch.utils.tensorboard import SummaryWriter

    _has_tensorboard = True
except ImportError:
    try:
        from tensorboardX import SummaryWriter

        _has_tensorboard = True
    except ImportError:
        _has_tensorboard = False


def is_tensorboard_available():
    return _has_tensorboard


try:
    import wandb

    wandb.ensure_configured()
    if wandb.api.api_key is None:
        _has_wandb = False
        wandb.termwarn("W&B installed but not logged in.  Run `wandb login` or set the WANDB_API_KEY env variable.")
    else:
        _has_wandb = False if os.getenv("WANDB_DISABLED") else True
except ImportError:
    _has_wandb = False


def is_wandb_available():
    return _has_wandb


logger = logging.getLogger(__name__)


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # ^^ safe to call this function even if cuda is not available


@contextmanager
def torch_distributed_zero_first(local_rank: int):
    """
    Decorator to make all processes in distributed training wait for each local_master to do something.
    """
    if local_rank not in [-1, 0]:
        torch.distributed.barrier()
    yield
    if local_rank == 0:
        torch.distributed.barrier()


def get_tpu_sampler(dataset: Dataset):
    if xm.xrt_world_size() <= 1:
        return RandomSampler(dataset)
    return DistributedSampler(dataset, num_replicas=xm.xrt_world_size(), rank=xm.get_ordinal())


def extract_spans_from_bio_tags(tags):
    """
    Extract spans indicated by BIO tags
    :param tags: list of bio tags
    :return: list of extracted spans [(start_idx, exclusive end_idx),...]
    """
    spans = []
    i = 0
    while i < len(tags):
        tag = tags[i]
        if tag.startswith('B'):
            start_idx = i
            while i + 1 < len(tags):
                if tags[i + 1].startswith('I') or tags[i + 1] == 'X':
                    i += 1
                else:
                    break
            end_idx = i + 1
            spans.append((start_idx, end_idx))
        i += 1
    return spans


class Trainer:
    """
    Trainer is a simple but feature-complete training and eval loop for PyTorch,
    optimized for Transformers.
    """

    # model: PreTrainedModel
    args: TrainingArguments
    model_args: ModelArguments
    data_args: DataTrainingArguments
    metadataloader: MetaDataloader
    tokenizer: DialogBertTokenizer
    compute_metrics: Optional[Callable[[EvalPrediction], Dict]] = None
    prediction_loss_only: bool
    tb_writer: Optional["SummaryWriter"] = None
    optimizers: Tuple[torch.optim.Optimizer, torch.optim.lr_scheduler.LambdaLR] = None
    global_step: Optional[int] = None
    epoch: Optional[float] = None

    def __init__(
        self,
        # model: PreTrainedModel,
        model,
        args: TrainingArguments,
        model_args: ModelArguments,
        data_args: DataTrainingArguments,
        metadataloader: MetaDataloader,
        tokenizer: DialogBertTokenizer,
        compute_metrics: Optional[Callable[[EvalPrediction], Dict]] = None,
        prediction_loss_only=False,
        tb_writer: Optional["SummaryWriter"] = None,
        optimizers: Tuple[torch.optim.Optimizer, torch.optim.lr_scheduler.LambdaLR] = None,
    ):
        """
        Trainer is a simple but feature-complete training and eval loop for PyTorch,
        optimized for Transformers.

        Args:
            prediction_loss_only:
                (Optional) in evaluation and prediction, only return the loss
        """
        self.model = model.to(args.device)
        self.args = args
        self.model_args = model_args
        self.data_args = data_args
        self.metadataloader = metadataloader
        self.tokenizer = tokenizer
        self.compute_metrics = compute_metrics
        self.prediction_loss_only = prediction_loss_only
        self.optimizers = optimizers
        if tb_writer is not None:
            self.tb_writer = tb_writer
        elif is_tensorboard_available() and self.is_world_master():
            if not self.args.logging_dir:
                log_dir = os.path.join(self.args.output_dir, 'log')
            else:
                log_dir = self.args.logging_dir
            self.tb_writer = SummaryWriter(log_dir=log_dir)
        if not is_tensorboard_available():
            logger.warning(
                "You are instantiating a Trainer but Tensorboard is not installed. You should consider installing it."
            )
        if is_wandb_available():
            self._setup_wandb()
        else:
            logger.info(
                "You are instantiating a Trainer but W&B is not installed. To use wandb logging, "
                "run `pip install wandb; wandb login` see https://docs.wandb.com/huggingface."
            )
        set_seed(self.args.seed)
        # Create output directory if needed
        if self.is_world_master():
            os.makedirs(self.args.output_dir, exist_ok=True)
        if is_tpu_available():
            # Set an xla_device flag on the model's config.
            # We'll find a more elegant and not need to do this in the future.
            self.model.config.xla_device = True

    def get_optimizers(
        self, num_training_steps: int
    ) -> Tuple[torch.optim.Optimizer, torch.optim.lr_scheduler.LambdaLR]:
        """
        Setup the optimizer and the learning rate scheduler.

        We provide a reasonable default that works well.
        If you want to use something else, you can pass a tuple in the Trainer's init,
        or override this method in a subclass.
        """
        if self.optimizers is not None:
            return self.optimizers
        # Prepare optimizer and schedule (linear warmup and decay)
        no_decay = ["bias", "LayerNorm.weight"]
        optimizer_grouped_parameters = [
            {
                "params": [p for n, p in self.model.named_parameters() if not any(nd in n for nd in no_decay)],
                "weight_decay": self.args.weight_decay,
            },
            {
                "params": [p for n, p in self.model.named_parameters() if any(nd in n for nd in no_decay)],
                "weight_decay": 0.0,
            },
        ]
        optimizer = AdamW(optimizer_grouped_parameters, lr=self.args.learning_rate, eps=self.args.adam_epsilon)
        if self.args.sche_type == "linear":
            scheduler = get_linear_schedule_with_warmup(
                optimizer, num_warmup_steps=self.args.warmup_steps, num_training_steps=num_training_steps
            )
        elif self.args.sche_type == "constant":
            scheduler = get_constant_schedule_with_warmup(
                optimizer, num_warmup_steps=self.args.warmup_steps
            )
        elif self.args.sche_type == "stair":
            decay_list = [(15000, 0.1)]
            scheduler = get_stair_schedule_with_warmup(
                optimizer, num_warmup_steps=self.args.warmup_steps, decay_list=decay_list
            )
        else:
            raise RuntimeError("No such scheduler type")
        return optimizer, scheduler

    def _setup_wandb(self):
        """
        Setup the optional Weights & Biases (`wandb`) integration.

        One can override this method to customize the setup if needed.  Find more information at https://docs.wandb.com/huggingface
        You can also override the following environment variables:

        Environment:
            WANDB_WATCH:
                (Optional, ["gradients", "all", "false"]) "gradients" by default, set to "false" to disable gradient logging
                or "all" to log gradients and parameters
            WANDB_PROJECT:
                (Optional): str - "huggingface" by default, set this to a custom string to store results in a different project
            WANDB_DISABLED:
                (Optional): boolean - defaults to false, set to "true" to disable wandb entirely
        """
        logger.info('Automatic Weights & Biases logging enabled, to disable set os.environ["WANDB_DISABLED"] = "true"')
        wandb.init(project=os.getenv("WANDB_PROJECT", "huggingface"), config=vars(self.args))
        # keep track of model topology and gradients
        if os.getenv("WANDB_WATCH") != "false":
            wandb.watch(
                self.model, log=os.getenv("WANDB_WATCH", "gradients"), log_freq=max(100, self.args.logging_steps)
            )

    def num_examples(self, dataloader: Union[DataLoader, "pl.PerDeviceLoader"]) -> int:
        """
        Helper to get num of examples from a DataLoader, by accessing its Dataset.
        """
        if is_tpu_available():
            assert isinstance(dataloader, pl.PerDeviceLoader)
            return len(dataloader._loader._loader.dataset)
        else:
            return len(dataloader.dataset)

    def train(self, model_path: Optional[str] = None):
        """
        Main training entry point.

        Args:
            model_path:
                (Optional) Local path to model if model to train has been instantiated from a local path
                If present, we will try reloading the optimizer/scheduler states from there.
        """
        # train_dataloader = self.get_train_dataloader()
        if self.args.max_steps > 0:
            t_total = self.args.max_steps
            # num_train_epochs = (
            #     self.args.max_steps // (len(train_dataloader) // self.args.gradient_accumulation_steps) + 1
            # )
        else:
            raise Exception('need to set max_steps')
            # t_total = int(len(train_dataloader) // self.args.gradient_accumulation_steps * self.args.num_train_epochs)
            # num_train_epochs = self.args.num_train_epochs

        optimizer, scheduler = self.get_optimizers(num_training_steps=t_total)

        # Check if saved optimizer or scheduler states exist
        if (
            model_path is not None
            and os.path.isfile(os.path.join(model_path, "optimizer.pt"))
            and os.path.isfile(os.path.join(model_path, "scheduler.pt"))
        ):
            # Load in optimizer and scheduler states
            print("load optimizer and scheduler from", model_path)
            optimizer.load_state_dict(
                torch.load(os.path.join(model_path, "optimizer.pt"), map_location=self.args.device)
            )
            scheduler.load_state_dict(torch.load(os.path.join(model_path, "scheduler.pt")))

        model = self.model
        if self.args.fp16:
            if not is_apex_available():
                raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
            model, optimizer = amp.initialize(model, optimizer, opt_level=self.args.fp16_opt_level)

        # multi-gpu training (should be after apex fp16 initialization)
        if self.args.n_gpu > 1:
            model = torch.nn.DataParallel(model)

        # for name, param in model.named_parameters():
        #     logger.info("param: {}, shape {}, device {}, req_grad {}".format(name, param.shape, param.device, param.requires_grad))

        logger.info(model)

        # Distributed training (should be after apex fp16 initialization)
        if self.args.local_rank != -1:
            model = torch.nn.parallel.DistributedDataParallel(
                model,
                device_ids=[self.args.local_rank],
                output_device=self.args.local_rank,
                find_unused_parameters=True,
            )

        if self.tb_writer is not None:
            self.tb_writer.add_text("args", self.args.to_json_string())
            self.tb_writer.add_hparams(self.args.to_sanitized_dict(), metric_dict={})

        # Train!
        if is_tpu_available():
            total_train_batch_size = self.args.train_batch_size * xm.xrt_world_size()
        else:
            total_train_batch_size = (
                self.args.train_batch_size
                * self.args.gradient_accumulation_steps
                * (torch.distributed.get_world_size() if self.args.local_rank != -1 else 1)
            )
        logger.info("***** Running training *****")
        # logger.info("  Num examples = %d", self.num_examples(train_dataloader))
        # logger.info("  Num Epochs = %d", num_train_epochs)
        logger.info("  n-gpu = %d", self.args.n_gpu)
        logger.info("  Instantaneous batch size per device = %d", self.args.per_gpu_train_batch_size)
        logger.info("  Total train batch size (w. parallel, distributed & accumulation) = %d", total_train_batch_size)
        logger.info("  Gradient Accumulation steps = %d", self.args.gradient_accumulation_steps)
        logger.info("  Total optimization steps = %d", t_total)

        self.global_step = 0
        self.epoch = 0
        # epochs_trained = 0
        # steps_trained_in_current_epoch = 0
        # Check if continuing training from a checkpoint
        if model_path is not None:
            # set global_step to global_step of last saved checkpoint from model path
            try:
                self.global_step = int(model_path.split("-")[-1].split("/")[0])
                # epochs_trained = self.global_step // (len(train_dataloader) // self.args.gradient_accumulation_steps)
                # steps_trained_in_current_epoch = self.global_step % (
                #     len(train_dataloader) // self.args.gradient_accumulation_steps
                # )

                logger.info("  Continuing training from checkpoint, will skip to saved global_step")
                # logger.info("  Continuing training from epoch %d", epochs_trained)
                logger.info("  Continuing training from global step %d", self.global_step)
                # logger.info("  Will skip the first %d steps in the first epoch", steps_trained_in_current_epoch)
            except ValueError:
                self.global_step = 0
                logger.info("  Starting fine-tuning.")

        tr_loss = {task:0.0 for task in self.metadataloader.tasks}
        tr_sub_loss = {task:defaultdict(float) for task in self.metadataloader.tasks}
        logging_loss = {task:0.0 for task in self.metadataloader.tasks}
        logging_sub_loss = {task:defaultdict(float) for task in self.metadataloader.tasks}
        if self.data_args.moco:
            tr_moco_acc = {topk:0.0 for topk in self.model.topk}
            logging_moco_acc = {topk:0.0 for topk in self.model.topk}
        model.zero_grad()
        total_forward_tokens = 0.
        # train_iterator = trange(
        #     epochs_trained, int(num_train_epochs), desc="Epoch", disable=not self.is_local_master()
        # )
        # trn_generator = {}
        # for task in self.metadataloader.tasks:
        #     trn_generator[task] = {}
        #     for dataset in self.data_args.dataset_config[task]:
        #         trn_generator[task][dataset] = self.metadataloader.processors[task].yield_batches(dataset,
        #                                                                                           batch_size=self.args.train_batch_size,
        #                                                                                           data_key='train')
        for step in tqdm(range(1, t_total + 1), desc="Iteration", disable=not self.is_local_master()):
            if self.global_step == 0:
                if self.args.evaluate_during_training and not self.data_args.moco:
                    metrics = self.evaluate(evaluate_during_training=True)
                    eval_loss, eval_acc = metrics['eval_losses'], metrics['eval_mlmacc']
                    # eval_loss_dataset = metrics['eval_losses_dataset']
                    # eval_acc_dataset = metrics['eval_mlmacc_dataset']
            for task in self.metadataloader.tasks:
                dataset = self.metadataloader.processors[task].sample_dataset(data_key='train')
                for forward_step in range(self.args.gradient_accumulation_steps):
                    if task is not "moco":
                        batch_data = self.metadataloader.processors[task].sample_batch(dataset,
                                                                                       batch_size=self.args.train_batch_size,
                                                                                       data_key='train')
                        if task == 'dapt':
                            total_forward_tokens += torch.sum(batch_data['input_ids']>0).item()
                    else:
                        try:
                            batch_data = next(trn_generator[task][dataset])
                        except StopIteration:
                            trn_generator[task][dataset] = self.metadataloader.processors[task].yield_batches(dataset,
                                                                                                              batch_size=self.args.train_batch_size,
                                                                                                              data_key='train')
                            batch_data = next(trn_generator[task][dataset])

                    if step > self.global_step:
                        batch_begin = (forward_step == 0)
                        batch_end = (forward_step == (self.args.gradient_accumulation_steps - 1))
                        loss, sub_losses, acc = self._training_step(model, batch_data, optimizer, task, dataset, batch_begin=batch_begin, batch_end=batch_end)
                        tr_loss[task] += loss
                        for k in sub_losses:
                            tr_sub_loss[task][k] = tr_sub_loss[task][k] + sub_losses[k]
                        if task == "moco":
                            for k in model.topk:
                                tr_moco_acc[k] += acc[k]

            if step <= self.global_step:
                continue
            if self.args.fp16:
                torch.nn.utils.clip_grad_norm_(amp.master_params(optimizer), self.args.max_grad_norm)
            else:
                torch.nn.utils.clip_grad_norm_(model.parameters(), self.args.max_grad_norm)

            if is_tpu_available():
                xm.optimizer_step(optimizer)
            else:
                optimizer.step()

            scheduler.step()
            model.zero_grad()
            self.global_step += 1
            # self.epoch = epoch + (step + 1) / len(epoch_iterator)

            if (self.args.logging_steps > 0 and self.global_step % self.args.logging_steps == 0) or (
                self.global_step == 1 and self.args.logging_first_step
            ):
                logs: Dict[str, float] = {}
                denominator = 1 if self.global_step == 1 else self.args.logging_steps
                for task in self.metadataloader.tasks:
                    logs["{}_loss".format(task)] = (tr_loss[task] - logging_loss[task]) / denominator
                    for sub in tr_sub_loss[task]:
                        logs["{}_{}_loss".format(task, sub)] = (tr_sub_loss[task][sub] - logging_sub_loss[task][sub]) / denominator
                if self.data_args.moco:
                    for k in self.model.topk:
                        logs["moco_acc_{}".format(k)] = (tr_moco_acc[k] - logging_moco_acc[k]) / (denominator * self.args.gradient_accumulation_steps)
                # backward compatibility for pytorch schedulers
                logs["learning_rate"] = (
                    scheduler.get_last_lr()[0]
                    if torch.__version__ >= "1.4"
                    else scheduler.get_lr()[0]
                )
                logs["total_forward_tokens"] = total_forward_tokens
                logging_loss = tr_loss.copy()
                logging_sub_loss = copy.deepcopy(tr_sub_loss)
                if self.data_args.moco:
                    logging_moco_acc = tr_moco_acc.copy()

                # print(logs)

                self._log(logs)

                if self.args.evaluate_during_training and not self.data_args.moco:
                    metrics = self.evaluate(evaluate_during_training=True)
                    task = self.metadataloader.tasks[0]
                    if self.is_world_master() and eval_loss[task] > metrics['eval_losses'][task] and eval_acc[task] < metrics['eval_mlmacc'][task]:
                        eval_loss, eval_acc = metrics['eval_losses'], metrics['eval_mlmacc']
                        # if self.args.save_steps > 0 and self.global_step % self.args.save_steps == 0:
                        # In all cases (even distributed/parallel), self.model is always a reference
                        # to the model we want to save.
                        if hasattr(model, "module"):
                            assert model.module is self.model
                        else:
                            assert model is self.model
                        # Save model checkpoint
                        output_dir = os.path.join(
                            self.args.output_dir, f"{PREFIX_CHECKPOINT_DIR}-{self.global_step}"
                        )

                        self.save_model(output_dir)
                        self._rotate_checkpoints()
                        torch.save(optimizer.state_dict(), os.path.join(output_dir, "optimizer.pt"))
                        torch.save(scheduler.state_dict(), os.path.join(output_dir, "scheduler.pt"))
                        logger.info("Saving optimizer and scheduler states to %s", output_dir)


                    # eval_loss_dataset = metrics['eval_losses_dataset']
                    # eval_acc_dataset = metrics['eval_mlmacc_dataset']

            if self.args.tpu_metrics_debug:
                # tpu-comment: Logging debug metrics for PyTorch/XLA (compile, execute times, ops, etc.)
                xm.master_print(met.metrics_report())

        if self.tb_writer:
            self.tb_writer.close()

        logger.info("\n\nTraining completed. Do not forget to share your model on huggingface.co/models =)\n\n")

    def evaluate(self, evaluate_during_training=False, checkpoint=None) -> Tuple:
        """
        Run evaluation and return metrics.

        The calling script will be responsible for providing a method to compute metrics, as they are
        task-dependent.
        """
        if checkpoint:
            logger.info("Evaluate the following checkpoint: %s", checkpoint)

            model = self.model.from_pretrained(checkpoint)
            model.to(self.args.device)
        else:
            model = self.model
        # multi-gpu eval
        if self.args.n_gpu > 1:
            model = torch.nn.DataParallel(model)

        # Note: in torch.distributed mode, there's no point in wrapping the model
        # inside a DistributedDataParallel as we'll be under `no_grad` anyways.

        if is_tpu_available():
            batch_size = self.args.eval_batch_size
        else:
            batch_size = self.args.eval_batch_size
        logger.info("***** Running %s *****", "Evaluation")
        logger.info("  Batch size = %d", batch_size)
        eval_losses = {task: [] for task in self.metadataloader.tasks}
        eval_losses_dataset = {task: {} for task in self.metadataloader.tasks}
        eval_mlmacc = {task: [] for task in self.metadataloader.tasks}
        eval_mlmacc_dataset = {task: {} for task in self.metadataloader.tasks}
        examples = {task: {} for task in self.metadataloader.tasks}
        if not evaluate_during_training:
            mlm_output = {}
            mlm_acc = {}
            cls_pos_mlm_output = {}
            cls_pos_mlm_acc = {}
            bio_output = {}
            bio_acc = {}
            bio_precision = {}
            bio_recall = {}
            bio_f1 = {}
            resp_output = {}
            resp_acc = {}

        model.eval()

        for task in self.metadataloader.tasks:
            for dataset in self.metadataloader.processors[task].datasets:
                eval_losses_dataset[task].setdefault(dataset, [])
                eval_mlmacc_dataset[task].setdefault(dataset, [])
                embeddings = []
                metadatas = []
                example2show = 0
                for batch_data in tqdm(list(self.metadataloader.processors[task].yield_batches(dataset, batch_size, 'dev'))):
                    batch_data = self._move_input_to_device(batch_data, self.args.device)

                    with torch.no_grad():
                        outputs = model(**batch_data, task=task, dataset=dataset, evaluate=True)
                        loss = outputs["loss"]

                    # TODO: add some examples for each task & dataset
                    if task == 'ssl':
                        if dataset not in examples[task]:
                            input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][0])
                            labels = batch_data['masked_lm_labels'][0]
                            prediction_scores = outputs["prediction_scores"][0]
                            _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                            example = []
                            for i, input_token in enumerate(input_tokens):
                                if input_token == '[MASK]':
                                    pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                    true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                    example.append(pred_token + input_token + true_token)
                                else:
                                    example.append(input_token)
                            example_sen = ' '.join(example)
                            examples[task][dataset] = example_sen
                            self._log({"eval_examples_{}_{}".format(task, dataset): examples[task][dataset]})

                            if 'bio_tag_ids' in batch_data:
                                labels = batch_data['bio_tag_ids'][0]
                                prediction_scores = outputs["bio_logits"][0]
                                _, prediction_tags = torch.max(prediction_scores, dim=-1)
                                tag_map = {1: 'B', 2: 'I', 0: 'O'}
                                prediction_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in
                                                   prediction_tags]
                                true_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in labels]
                                example = []
                                for i, input_token in enumerate(input_tokens):
                                    if prediction_tags[i] in ['B', 'I']:
                                        input_token = "(**{}**)".format(prediction_tags[i]) + input_token
                                    if true_tags[i] in ['B', 'I']:
                                        input_token += "(**{}**)".format(true_tags[i])
                                    example.append(input_token)
                                example_sen = ' '.join(example)
                                examples[task][dataset] = example_sen
                                self._log({"eval_examples_{}_{}".format(task, dataset): examples[task][dataset]})

                        if not evaluate_during_training:
                            mlm_output.setdefault(dataset, [])
                            mlm_acc.setdefault(dataset, [])
                            for i in range(len(batch_data['input_ids'])):
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                                labels = batch_data['masked_lm_labels'][i]
                                prediction_scores = outputs["prediction_scores"][i]
                                _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                                example = []
                                for i, input_token in enumerate(input_tokens):
                                    if input_token == '[MASK]':
                                        pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                        true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                        mlm_acc[dataset].append(pred_token == true_token)
                                        example.append(pred_token + input_token + true_token)
                                    else:
                                        example.append(input_token)
                                example_sen = ' '.join(example)
                                mlm_output[dataset].append(example_sen)

                            if 'bio_tag_ids' in batch_data:
                                bio_output.setdefault(dataset, [])
                                bio_acc.setdefault(dataset, [])
                                bio_precision.setdefault(dataset, [])
                                bio_recall.setdefault(dataset, [])
                                bio_f1.setdefault(dataset, [])
                                for i in range(len(batch_data['input_ids'])):
                                    input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                                    labels = batch_data['bio_tag_ids'][i]
                                    prediction_scores = outputs["bio_logits"][i]
                                    _, prediction_tags = torch.max(prediction_scores, dim=-1)
                                    tag_map = {1: 'B', 2: 'I', 0: 'O'}
                                    prediction_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in
                                                       prediction_tags]
                                    true_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in labels]
                                    prediction_spans = set(extract_spans_from_bio_tags(prediction_tags))
                                    true_spans = set(extract_spans_from_bio_tags(true_tags))
                                    TP = len(prediction_spans & true_spans)
                                    precision = 1.0 * TP / len(prediction_spans) if len(prediction_spans) else 0.
                                    recall = 1.0 * TP / len(true_spans) if len(true_spans) else 0.
                                    F1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.
                                    bio_precision[dataset].append(precision)
                                    bio_recall[dataset].append(recall)
                                    bio_f1[dataset].append(F1)
                                    example = []
                                    for i, input_token in enumerate(input_tokens):
                                        if prediction_tags[i] in ['B', 'I']:
                                            input_token = "(**{}**)".format(prediction_tags[i]) + input_token
                                        if true_tags[i] in ['B', 'I']:
                                            input_token += "(**{}**)".format(true_tags[i])
                                        if true_tags[i] in ['B', 'I', 'O']:
                                            bio_acc[dataset].append(prediction_tags[i] == true_tags[i])
                                        example.append(input_token)
                                    example_sen = ' '.join(example)
                                    bio_output[dataset].append(example_sen)
                    elif task == 'schema_linking' and 'masked_lm_labels' in batch_data:
                        if dataset not in examples[task]:
                            input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][0])
                            labels = batch_data['masked_lm_labels'][0]
                            prediction_scores = outputs["prediction_scores"][0]
                            _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                            example = []
                            for i, (input_token, label) in enumerate(zip(input_tokens, labels)):
                                if label != -100:
                                    pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                    true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                    example.append(pred_token + '{' + input_token + '}' + true_token)
                                else:
                                    example.append(input_token)
                            example_sen = ' '.join(example)
                            examples[task][dataset] = example_sen
                            self._log({"eval_examples_{}_{}".format(task, dataset): examples[task][dataset]})
                        if not evaluate_during_training:
                            mlm_output.setdefault(dataset, [])
                            mlm_acc.setdefault(dataset, [])
                            for i in range(len(batch_data['input_ids'])):
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                                labels = batch_data['masked_lm_labels'][i]
                                prediction_scores = outputs["prediction_scores"][i]
                                _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                                example = []
                                for i, (input_token, label) in enumerate(zip(input_tokens, labels)):
                                    if label != -100:
                                        pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                        true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                        mlm_acc[dataset].append(pred_token==true_token)
                                        example.append(pred_token + '{' + input_token + '}' + true_token)
                                    else:
                                        example.append(input_token)
                                example_sen = ' '.join(example)
                                mlm_output[dataset].append(example_sen)
                    elif task == 'augdial':
                        if dataset+"_aug0" not in examples[task]:
                            torch.set_printoptions(profile="full")
                            print("=" * 100)
                            print('turn num')
                            print(torch.max(batch_data["batches"][0]["turn_ids"], dim=-1))
                            # print(outputs["aug{}_sim_mat".format(1)])
                            for j in range(len(batch_data["batches"])):
                                if "aug{}_sim_acc".format(j) in outputs:
                                    print("aug{}_sim_acc".format(j), outputs["aug{}_sim_acc".format(j)])
                                for k in ["aug{}_sim_dist".format(j), "aug{}_cossim".format(j)]:
                                    if k in outputs:
                                        print('argmax', k)
                                        print(torch.max(outputs[k], dim=-1).indices)
                                        print('first sample')
                                        print(outputs[k][0])
                            print("=" * 100)
                            for j, batch in enumerate(batch_data["batches"]):
                                if 'masked_lm_labels' not in batch or "prediction_scores_aug{}".format(j) not in outputs:
                                    continue
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch['input_ids'][0])
                                labels = batch['masked_lm_labels'][0]
                                prediction_scores = outputs["prediction_scores_aug{}".format(j)][0]
                                _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                                example = []
                                for i, (input_token, label) in enumerate(zip(input_tokens, labels)):
                                    if label != -100:
                                        pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                        true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                        example.append(pred_token + '{' + input_token + '}' + true_token)
                                    else:
                                        example.append(input_token)
                                example_sen = ' '.join(example)
                                examples[task][dataset+"_aug{}".format(j)] = example_sen
                                self._log({"eval_examples_{}_{}_aug{}".format(task, dataset, j): examples[task][
                                    dataset + "_aug{}".format(j)]})
                        if not evaluate_during_training:
                            for j, batch in enumerate(batch_data["batches"]):
                                if 'masked_lm_labels' not in batch or "prediction_scores_aug{}".format(j) not in outputs:
                                    continue
                                mlm_acc.setdefault(dataset+"_aug{}".format(j), [])
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch['input_ids'][0])
                                labels = batch['masked_lm_labels'][0]
                                prediction_scores = outputs["prediction_scores_aug{}".format(j)][0]
                                _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                                for i, (input_token, label) in enumerate(zip(input_tokens, labels)):
                                    if label != -100:
                                        pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                        true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                        mlm_acc[dataset+"_aug{}".format(j)].append(pred_token == true_token)
                    elif task in ['dapt', 'mlm', 'one_side_mlm', 'last_turn_mlm', 'span_mlm', 'cls_mlm', 'cls_pos_mlm']:
                        if dataset not in examples[task]:
                            input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][0])
                            labels = batch_data['masked_lm_labels'][0]
                            prediction_scores = outputs["prediction_scores"][0]
                            _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                            example = []
                            for i, (input_token, label) in enumerate(zip(input_tokens, labels)):
                                if label != -100:
                                    pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                    true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                    example.append(pred_token + '{' + input_token + '}' + true_token)
                                else:
                                    example.append(input_token)
                            example_sen = ' '.join(example)
                            examples[task][dataset] = example_sen
                            self._log({"eval_examples_{}_{}".format(task, dataset): examples[task][dataset]})

                            if task == 'cls_pos_mlm':
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][0])
                                labels = batch_data['masked_lm_labels'][0]
                                prediction_scores = outputs["cls_output"][0]
                                _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                                example = []
                                for i, input_token in enumerate(input_tokens):
                                    if input_token == '[MASK]':
                                        pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                        true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                        example.append(pred_token+input_token+true_token)
                                    else:
                                        example.append(input_token)
                                example_sen = ' '.join(example)
                                examples[task][dataset] = example_sen
                                self._log({"eval_examples_cls_{}".format(task, dataset): examples[task][dataset]})

                        masked_lm_labels = batch_data['masked_lm_labels']
                        prediction = torch.argmax(outputs["prediction_scores"], dim=-1)  # (batch_size, seq_len)
                        pred_mask = (masked_lm_labels != -100)
                        correct = (prediction == masked_lm_labels)[pred_mask].tolist()
                        eval_mlmacc_dataset[task][dataset].extend(correct)
                        if dataset in self.metadataloader.processors[task].train_datasets:
                            eval_mlmacc[task].extend(correct)
                        # if not evaluate_during_training:
                        #     mlm_output.setdefault(dataset, [])
                        #     mlm_acc.setdefault(dataset, [])
                        #     for i in range(len(batch_data['input_ids'])):
                        #         input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                        #         labels = batch_data['masked_lm_labels'][i]
                        #         prediction_scores = outputs["prediction_scores"][i]
                        #         _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                        #         example = []
                        #         for i, (input_token, label) in enumerate(zip(input_tokens, labels)):
                        #             if label != -100:
                        #                 pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                        #                 true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                        #                 mlm_acc[dataset].append(pred_token==true_token)
                        #                 example.append(pred_token + '{' + input_token + '}' + true_token)
                        #             else:
                        #                 example.append(input_token)
                        #         example_sen = ' '.join(example)
                        #         mlm_output[dataset].append(example_sen)
                        #
                        #     if task == "cls_pos_mlm":
                        #         cls_pos_mlm_output.setdefault(dataset, [])
                        #         cls_pos_mlm_acc.setdefault(dataset, [])
                        #         for i in range(len(batch_data['input_ids'])):
                        #             input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                        #             labels = batch_data['masked_lm_labels'][i]
                        #             prediction_scores = outputs["cls_output"][i]
                        #             _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                        #             example = []
                        #             for i, input_token in enumerate(input_tokens):
                        #                 if input_token == '[MASK]':
                        #                     pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                        #                     true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                        #                     cls_pos_mlm_acc[dataset].append(pred_token==true_token)
                        #                     example.append(pred_token + input_token + true_token)
                        #                 else:
                        #                     example.append(input_token)
                        #             example_sen = ' '.join(example)
                        #             cls_pos_mlm_output[dataset].append(example_sen)
                    elif task in ["resp_select"]:
                        if dataset not in examples[task]:
                            input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][0])
                            labels = batch_data['masked_lm_labels'][0]
                            prediction_scores = outputs["prediction_scores"][0]
                            _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                            example = []
                            for i, input_token in enumerate(input_tokens):
                                if input_token == '[MASK]':
                                    pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                    true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                    example.append(pred_token+input_token+true_token)
                                else:
                                    example.append(input_token)
                            example_sen = ' '.join(example)
                            examples[task][dataset] = example_sen
                            self._log({"eval_examples_{}_{}".format(task, dataset): examples[task][dataset]})

                        if not evaluate_during_training:
                            mlm_output.setdefault(dataset, [])
                            mlm_acc.setdefault(dataset, [])
                            for i in range(len(batch_data['input_ids'])):
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                                labels = batch_data['masked_lm_labels'][i]
                                prediction_scores = outputs["prediction_scores"][i]
                                _, prediction_tokens = torch.max(prediction_scores, dim=-1)
                                example = []
                                for i, input_token in enumerate(input_tokens):
                                    if input_token == '[MASK]':
                                        pred_token = self.tokenizer.convert_ids_to_tokens(prediction_tokens[i].item())
                                        true_token = self.tokenizer.convert_ids_to_tokens(labels[i].item())
                                        mlm_acc[dataset].append(pred_token==true_token)
                                        example.append(pred_token + input_token + true_token)
                                    else:
                                        example.append(input_token)
                                example_sen = ' '.join(example)
                                mlm_output[dataset].append(example_sen)

                            resp_output.setdefault(dataset, [])
                            resp_acc.setdefault(dataset, [])
                            resp_preds = torch.argmax(outputs["resp_scores"], dim=-1)
                            resp_labels = batch_data["resp_labels"]
                            bs = len(batch_data['input_ids']) // 2
                            for i in range(bs):
                                context_tokens = self.tokenizer.convert_ids_to_tokens(batch_data["input_ids"][i])
                                resp_truth_tokens = self.tokenizer.convert_ids_to_tokens(batch_data["input_ids"][bs + resp_labels[i]])
                                resp_pred_tokens = self.tokenizer.convert_ids_to_tokens(batch_data["input_ids"][bs + resp_preds[i]])
                                resp_acc[dataset].append(int(resp_preds[i] == resp_labels[i]))
                                example.append({
                                    "ctx": context_tokens,
                                    "preds": resp_pred_tokens,
                                    "truth": resp_truth_tokens
                                })

                    elif task in ['bio']:
                        if dataset not in examples[task]:
                            input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][0])
                            labels = batch_data['bio_tag_ids'][0]
                            prediction_scores = outputs["bio_logits"][0]
                            _, prediction_tags = torch.max(prediction_scores, dim=-1)
                            tag_map = {1: 'B', 2: 'I', 0: 'O'}
                            prediction_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in prediction_tags]
                            true_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in labels]
                            example = []
                            for i, input_token in enumerate(input_tokens):
                                if prediction_tags[i] in ['B', 'I']:
                                    input_token = "(**{}**)".format(prediction_tags[i]) + input_token
                                if true_tags[i] in ['B', 'I']:
                                    input_token += "(**{}**)".format(true_tags[i])
                                example.append(input_token)
                            example_sen = ' '.join(example)
                            examples[task][dataset] = example_sen
                            self._log({"eval_examples_{}_{}".format(task, dataset): examples[task][dataset]})
                        if not evaluate_during_training:
                            bio_output.setdefault(dataset, [])
                            bio_acc.setdefault(dataset, [])
                            bio_precision.setdefault(dataset, [])
                            bio_recall.setdefault(dataset, [])
                            bio_f1.setdefault(dataset, [])
                            for i in range(len(batch_data['input_ids'])):
                                input_tokens = self.tokenizer.convert_ids_to_tokens(batch_data['input_ids'][i])
                                labels = batch_data['bio_tag_ids'][i]
                                prediction_scores = outputs["bio_logits"][i]
                                _, prediction_tags = torch.max(prediction_scores, dim=-1)
                                tag_map = {1: 'B', 2: 'I', 0: 'O'}
                                prediction_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in
                                                   prediction_tags]
                                true_tags = [tag_map[tag.item()] if tag.item() in tag_map else 'X' for tag in labels]
                                prediction_spans = set(extract_spans_from_bio_tags(prediction_tags))
                                true_spans = set(extract_spans_from_bio_tags(true_tags))
                                TP = len(prediction_spans & true_spans)
                                precision = 1.0 * TP / len(prediction_spans) if len(prediction_spans) else 0.
                                recall = 1.0 * TP / len(true_spans) if len(true_spans) else 0.
                                F1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.
                                bio_precision[dataset].append(precision)
                                bio_recall[dataset].append(recall)
                                bio_f1[dataset].append(F1)
                                example = []
                                for i, input_token in enumerate(input_tokens):
                                    if prediction_tags[i] in ['B', 'I']:
                                        input_token = "(**{}**)".format(prediction_tags[i]) + input_token
                                    if true_tags[i] in ['B', 'I']:
                                        input_token += "(**{}**)".format(true_tags[i])
                                    if true_tags[i] in ['B', 'I', 'O']:
                                        bio_acc[dataset].append(prediction_tags[i] == true_tags[i])
                                    example.append(input_token)
                                example_sen = ' '.join(example)
                                bio_output[dataset].append(example_sen)

                    if self.args.n_gpu > 1:
                        loss = loss.mean()  # mean() to average on multi-gpu parallel training
                    loss = loss.item()
                    eval_losses_dataset[task][dataset].append(loss)
                    if dataset in self.metadataloader.processors[task].train_datasets:
                        eval_losses[task].append(loss)
                eval_losses_dataset[task][dataset] = np.mean(eval_losses_dataset[task][dataset]) # batch loss or step loss
                self._log({"eval_losses_{}_{}".format(task, dataset): eval_losses_dataset[task][dataset]})
                eval_mlmacc_dataset[task][dataset] = np.mean(eval_mlmacc_dataset[task][dataset])
                self._log({"eval_mlmacc_{}_{}".format(task, dataset): eval_mlmacc_dataset[task][dataset]})
                if task == 'schema_linking' and not evaluate_during_training and dataset=='multiwoz25':
                    # print(embeddings)
                    embeddings = torch.cat(embeddings, dim=0)
                    print(embeddings.size())
                    self.tb_writer.add_embedding(embeddings, metadata=metadatas, tag='token_repr', metadata_header=['emb\ttype'],
                                                 global_step=self.global_step)
            eval_losses[task] = np.mean(eval_losses[task])
            self._log({"eval_losses_{}".format(task): eval_losses[task]})
            eval_mlmacc[task] = np.mean(eval_mlmacc[task])
            self._log({"eval_mlmacc_{}".format(task): eval_mlmacc[task]})

        if not evaluate_during_training:
            if mlm_acc:
                for dataset in mlm_acc:
                    mlm_acc[dataset] = np.mean(mlm_acc[dataset])
                    self._log({"eval_mlm_acc_{}".format(dataset): mlm_acc[dataset]})
            if cls_pos_mlm_acc:
                for dataset in cls_pos_mlm_acc:
                    cls_pos_mlm_acc[dataset] = np.mean(cls_pos_mlm_acc[dataset])
                    self._log({"eval_cls_pos_mlm_acc_{}".format(dataset) : cls_pos_mlm_acc[dataset]})
            if bio_acc:
                for dataset in bio_acc:
                    bio_acc[dataset] = np.mean(bio_acc[dataset])
                    self._log({"eval_bio_acc_{}".format(dataset): bio_acc[dataset]})
            if bio_f1:
                for dataset in bio_f1:
                    bio_f1[dataset] = np.mean(bio_f1[dataset])
                    self._log({"eval_bio_f1_{}".format(dataset): bio_f1[dataset]})
            if bio_precision:
                for dataset in bio_precision:
                    bio_precision[dataset] = np.mean(bio_precision[dataset])
                    self._log({"eval_bio_precision_{}".format(dataset): bio_precision[dataset]})
            if bio_recall:
                for dataset in bio_recall:
                    bio_recall[dataset] = np.mean(bio_recall[dataset])
                    self._log({"eval_bio_recall_{}".format(dataset): bio_recall[dataset]})
            if resp_acc:
                for dataset in resp_acc:
                    resp_acc[dataset] = np.mean(resp_acc[dataset])
                    self._log({"eval_resp_acc_{}".format(dataset): mlm_acc[dataset]})

        metrics = {"eval_losses_dataset": eval_losses_dataset,
                   "eval_losses": eval_losses,
                   "eval_mlmacc_dataset": eval_mlmacc_dataset,
                   "eval_mlmacc": eval_mlmacc,
                   "eval_examples": examples
                   }

        # if not evaluate_during_training:
        #     if mlm_acc:
        #         metrics[0]['mlm_acc'] = mlm_acc
        #     if bio_acc:
        #         metrics[0]['bio_acc'] = bio_acc
        #     if bio_f1:
        #         metrics[0]['bio_f1'] = bio_f1
        #     if bio_precision:
        #         metrics[0]['bio_precision'] = bio_precision
        #     if bio_recall:
        #         metrics[0]['bio_recall'] = bio_recall
        #     if resp_acc:
        #         metrics[0]['resp_acc'] = resp_acc
        #     if mlm_output:
        #         metrics += (mlm_output,)
        #     if bio_output:
        #         metrics += (bio_output,)
        return metrics

    def _log(self, logs: Dict[str, float or str], iterator: Optional[tqdm] = None) -> None:

        if self.epoch is not None:
            logs["epoch"] = self.epoch
        if self.tb_writer:
            for k, v in logs.items():
                if isinstance(v, float):
                    self.tb_writer.add_scalar(k, v, self.global_step)
                elif isinstance(v, str):
                    self.tb_writer.add_text(k, v, self.global_step)
        if is_wandb_available():
            wandb.log(logs, step=self.global_step)
        output = json.dumps({**logs, **{"step": self.global_step}})
        if iterator is not None:
            iterator.write(output)
        else:
            print(output)

    def _move_input_to_device(self, inputs, device):
        if isinstance(inputs, list):
            return [self._move_input_to_device(v, device) for v in inputs]
        elif isinstance(inputs, dict):
            return {k: self._move_input_to_device(v, device) for k, v in inputs.items()}
        elif isinstance(inputs, torch.Tensor):
            return inputs.to(device)
        else:
            return inputs

    def _training_step(
        self, model: nn.Module, inputs: Dict[str, torch.Tensor], optimizer: torch.optim.Optimizer, task, dataset, batch_begin=False, batch_end=False
    ) -> float:
        model.train()
        inputs = self._move_input_to_device(inputs, self.args.device)
        if self.data_args.moco:
            inputs["update_k_encoder"] = batch_begin
            inputs["update_queue"] = batch_end
        outputs = model(task=task, dataset=dataset, **inputs)
        loss = outputs["loss"]
        acc = outputs.get("acc", None)
        # loss = outputs[0]  # model outputs are always tuple in transformers (see doc)

        if self.args.n_gpu > 1:
            loss = loss.mean()  # mean() to average on multi-gpu parallel training
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps

        if self.args.fp16:
            with amp.scale_loss(loss, optimizer) as scaled_loss:
                scaled_loss.backward()
        else:
            loss.backward()

        sub_losses = {x: (outputs[x].mean().item() if not isinstance(outputs[x], (int, float)) else outputs[x]) / self.args.gradient_accumulation_steps for x in outputs if "_loss" in x}

        return loss.item(), sub_losses, acc

    def is_local_master(self) -> bool:
        if is_tpu_available():
            return xm.is_master_ordinal(local=True)
        else:
            return self.args.local_rank in [-1, 0]

    def is_world_master(self) -> bool:
        """
        This will be True only in one process, even in distributed mode,
        even when training on multiple machines.
        """
        if is_tpu_available():
            return xm.is_master_ordinal(local=False)
        else:
            return self.args.local_rank == -1 or torch.distributed.get_rank() == 0

    def save_model(self, output_dir: Optional[str] = None):
        """
        Saving best-practices: if you use default names for the model,
        you can reload it using from_pretrained().

        Will only save from the world_master process (unless in TPUs).
        """

        if is_tpu_available():
            self._save_tpu(output_dir)
        elif self.is_world_master():
            self._save(output_dir)

    def _save_tpu(self, output_dir: Optional[str] = None):
        output_dir = output_dir if output_dir is not None else self.args.output_dir
        logger.info("Saving model checkpoint to %s", output_dir)

        if xm.is_master_ordinal():
            os.makedirs(output_dir, exist_ok=True)
            torch.save(self.args, os.path.join(output_dir, "training_args.bin"))

        # Save a trained model and configuration using `save_pretrained()`.
        # They can then be reloaded using `from_pretrained()`
        if not isinstance(self.model, PreTrainedModel):
            raise ValueError("Trainer.model appears to not be a PreTrainedModel")

        xm.rendezvous("saving_checkpoint")
        self.model.save_pretrained(output_dir)

    def _save(self, output_dir: Optional[str] = None):
        output_dir = output_dir if output_dir is not None else self.args.output_dir
        os.makedirs(output_dir, exist_ok=True)
        logger.info("Saving model checkpoint to %s", output_dir)
        # Save a trained model and configuration using `save_pretrained()`.
        # They can then be reloaded using `from_pretrained()`
        if self.data_args.moco:
            self.model.save(output_dir)
        else:
            if not isinstance(self.model, PreTrainedModel):
                raise ValueError("Trainer.model appears to not be a PreTrainedModel")
            self.model.save_pretrained(output_dir)
        self.tokenizer.save_pretrained(output_dir)

        # Good practice: save your training arguments together with the trained model
        torch.save(self.args, os.path.join(output_dir, "training_args.bin"))

    def _sorted_checkpoints(self, checkpoint_prefix=PREFIX_CHECKPOINT_DIR, use_mtime=False) -> List[str]:
        ordering_and_checkpoint_path = []

        glob_checkpoints = [str(x) for x in Path(self.args.output_dir).glob(f"{checkpoint_prefix}-*")]

        for path in glob_checkpoints:
            if use_mtime:
                ordering_and_checkpoint_path.append((os.path.getmtime(path), path))
            else:
                regex_match = re.match(f".*{checkpoint_prefix}-([0-9]+)", path)
                if regex_match and regex_match.groups():
                    ordering_and_checkpoint_path.append((int(regex_match.groups()[0]), path))

        checkpoints_sorted = sorted(ordering_and_checkpoint_path)
        checkpoints_sorted = [checkpoint[1] for checkpoint in checkpoints_sorted]
        return checkpoints_sorted

    def _rotate_checkpoints(self, use_mtime=False) -> None:
        if self.args.save_total_limit is None or self.args.save_total_limit <= 0:
            return

        # Check if we should delete older checkpoint(s)
        checkpoints_sorted = self._sorted_checkpoints(use_mtime=use_mtime)
        if len(checkpoints_sorted) <= self.args.save_total_limit:
            return

        number_of_checkpoints_to_delete = max(0, len(checkpoints_sorted) - self.args.save_total_limit)
        checkpoints_to_be_deleted = checkpoints_sorted[:number_of_checkpoints_to_delete]
        for checkpoint in checkpoints_to_be_deleted:
            logger.info("Deleting older checkpoint [{}] due to args.save_total_limit".format(checkpoint))
            if os.path.exists(checkpoint):
                shutil.rmtree(checkpoint)

    def distributed_concat(self, tensor: torch.Tensor, num_total_examples: int) -> torch.Tensor:
        assert self.args.local_rank != -1

        output_tensors = [tensor.clone() for _ in range(torch.distributed.get_world_size())]
        torch.distributed.all_gather(output_tensors, tensor)

        concat = torch.cat(output_tensors, dim=0)

        # truncate the dummy elements added by SequentialDistributedSampler
        output = concat[:num_total_examples]
        return output
