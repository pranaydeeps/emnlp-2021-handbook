This is the public version of TripPy.

Supported datasets are:
simM, simR, woz2, multiwoz2.1

Requirements:
transformers
tensorboardX
