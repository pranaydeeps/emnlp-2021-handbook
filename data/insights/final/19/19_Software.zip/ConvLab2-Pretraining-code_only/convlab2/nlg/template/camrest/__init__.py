from convlab2.nlg.template.camrest.nlg import TemplateNLG
