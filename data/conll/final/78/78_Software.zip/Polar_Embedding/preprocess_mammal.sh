#!/usr/bin/env bash

mkdir -p ./data/mammal

python getMammalClosure.py
mv mammal_closure.csv ./data/mammal

python makeSupervisedContextMammal.py

python getHeightsAndDepths.py ./data/mammal/mammal_closure.tsv.vocab ./data/mammal/mammal_closure.tsv
python getEdgeCount.py --vocab ./data/mammal/mammal_closure.tsv.vocab --tsv ./data/mammal/mammal_closure.tsv

