# Polar_Embedding

## Data preprocessing

```
# Noun dataset (This will take long time)
sh ./preprocess_noun.sh

# Mammal dataset
sh ./preprocess_mammal.sh

# Estimate true angle distribution using GMM
python estimateGMM.py
```
## Training Example
```
# Noun dataset
python makePolarEmbedding.py  -t 10 -dim 5 -iter 500000 -batch 1024 -nratio 0.1 
                              -alpha 0.1 --SVGD -svgd_interval 10000 --svgd_epoch 20 -svgd_workers 0 
# Mammal dataset
python makePolarEmbedding.py  -dim 5 -iter 500000 -batch 128 -nratio 0.1 -alpha 0.1 --SVGD -svgd_interval 1000
                              --svgd_epoch 20 -svgd_workers 0 --mammal
```
# Test
```
python testPolarEmbedding.py --model [model path]
```
