#!/usr/bin/env bash

git clone https://github.com/lapras-inc/disk-embedding.git

mv  ./disk-embedding/data/maxn ./data/noun

for f in `find ./data/noun -name "noun_closure.tsv.train_*"`;
do
    python getHeightsAndDepths.py ./data/noun/noun_closure.tsv.vocab $f
    python getEdgeCount.py --tsv $f --vocab ./data/noun/noun_closure.tsv.vocab
done

python makeSupervisedContextNoun.py