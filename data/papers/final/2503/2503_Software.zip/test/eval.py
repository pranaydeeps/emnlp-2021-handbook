import json


root_dir = "/resources/semqa/checkpoints/drop_lang_depr/date_num/date_numcq_hmvy_cnt_relprog_500_no_exec/drop_parser/TOKENS_qanet/ED_100/RG_1e-07/MODELTYPE_encoded/CNTFIX_false/aux_true/SUPEPOCHS_5/"
root_dirs = [
    root_dir + "S_1/NewModel/predictions",
    root_dir + "S_10/NewModel/predictions",
    root_dir + "S_100/NewModel/predictions",
]
