# Number comparison questions

Prune, distantly-supervise, augment, and limit-annotations for
number comparison questions.

Questions looking at now -- "Were there more/fewer"
"Which group X", "Which group X"

