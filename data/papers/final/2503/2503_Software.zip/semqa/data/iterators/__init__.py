from semqa.data.iterators.filter_iterator import DataFilterIterator
