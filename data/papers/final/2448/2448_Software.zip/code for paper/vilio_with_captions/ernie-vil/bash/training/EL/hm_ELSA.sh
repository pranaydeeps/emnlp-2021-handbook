#bash -x ./env.sh

# Simple Average
python utils/ens.py --enspath ./data/hm/ --enstype sa --exp EL365072