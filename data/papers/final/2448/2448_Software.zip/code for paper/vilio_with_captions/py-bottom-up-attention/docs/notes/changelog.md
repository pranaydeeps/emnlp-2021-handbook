# Change Log


### Notable Changes:

* 2019-11-11: `detectron2.data.detection_utils.read_image` transposes images with exif information.
* 2019-10-10: initial release.

### Config Version Change Log

* v1: Rename `RPN_HEAD.NAME` to `RPN.HEAD_NAME`.
* v2: A batch of rename of many configurations before release.
