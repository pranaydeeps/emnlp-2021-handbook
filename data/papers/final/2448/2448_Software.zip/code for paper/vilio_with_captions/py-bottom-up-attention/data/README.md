Place an img folder here which contains all the images to be extracted.

Alternatively, you can also modify the dataroot in detectron2_mscoco_proposal_maxnms.py directly or with the --dataroot argument. Again make sure you point only to the datafolder, and within that datafolder there is an img folder. 

This is also the folder where the tsv file will be outputted to.