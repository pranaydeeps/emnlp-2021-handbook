#!/bin/bash

# Simple Average U-Model outputs
python utils/ens.py --enspath ./data/ --enstype sa --exp U365072