#!/bin/bash

# Simple Average D-Model outputs
python utils/ens.py --enspath ./data/ --enstype sa --exp D507236