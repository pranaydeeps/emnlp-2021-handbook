#!/bin/bash

# Simple Average
python utils/ens.py --enspath ./data/ --enstype loop --exp ENS