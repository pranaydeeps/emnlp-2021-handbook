#!/bin/bash

# Simple Average
python utils/ens.py --enspath ./data/ --enstype sa --exp U365072