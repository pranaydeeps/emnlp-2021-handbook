#!/bin/bash

# Extract lmdb features
python fts_lmdb/lmdb_conversion.py