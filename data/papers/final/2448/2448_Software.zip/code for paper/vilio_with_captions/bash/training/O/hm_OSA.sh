#!/bin/bash

# Simple Average O-Model outputs
python utils/ens.py --enspath ./data/ --enstype sa --exp O365050