

class CONFIG(object):
    """docstring for CONFIG"""
    def __init__(self):
        super(CONFIG, self).__init__()
        
        self.dataset = 'R8'
        self.model = 'supercls'  # 'gcn', 'gcn_cheby', 'dense'
        self.learning_rate = 0.001   # Initial learning rate.
        self.epochs = 2000  # Number of epochs to train.
        self.hidden1 = 300  # Number of units in hidden layer 1.
        self.dropout = 0.5  # Dropout rate (1 - keep probability).
        self.weight_decay = 0.000000   # Weight for L2 loss on embedding matrix.
        self.early_stopping = 10 # Tolerance for early stopping (# of epochs).
        self.max_degree = 3      # Maximum Chebyshev polynomial degree.
        self.gpu = 6
        #self.classes = [9,137,798]
        #self.classes = [9,61]
        #self.classes = [7,150]
        #self.classes = [20,129,347,441]
        self.classes = [9,137,798,9162]
        #self.classes = [9,137]
        self.batch_size = 200
        self.threshold = 0.52
        self.step_size = 300
        #classes = [9,137,798,9162]
        self.alpha = {"0":1,
                      '1':1,
                      '2':1,
                      '3':1,
                      'g':1,
                      'sc0':0.5,
                      'sc1':0.5}



