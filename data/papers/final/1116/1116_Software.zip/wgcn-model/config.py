

class CONFIG(object):
    """docstring for CONFIG"""
    def __init__(self):
        super(CONFIG, self).__init__()
        
        self.dataset = 'Ohsumed'
        self.model = 'single'  # 'gcn', 'gcn_cheby', 'dense'
        self.learning_rate = 0.001   # Initial learning rate.
        self.epochs = 2000  # Number of epochs to train.
        self.hidden1 = 300  # Number of units in hidden layer 1.
        self.dropout = 0.5  # Dropout rate (1 - keep probability).
        self.weight_decay = 0.00000   # Weight for L2 loss on embedding matrix.
        self.early_stopping = 10 # Tolerance for early stopping (# of epochs).
        self.max_degree = 3      # Maximum Chebyshev polynomial degree.
        self.gpu = 6
        #self.classes = [9,137]
        self.classes = [8]
        #self.classes = [9,137,798,9162]
        self.batch_size = 7000
        self.threshold = 0.5
        self.step_size = 200
        #classes = [9,137,798,9162]
        self.alpha = {"g":1, '1':0, '2':0,'3':0}



