python ./translate_en-es.py --test-batch-size 32 \
                            --empty-cache-freq 1