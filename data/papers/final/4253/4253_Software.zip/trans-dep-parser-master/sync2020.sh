#!/bin/zsh
# 8020
# rsync -avz -e 'ssh -p 8020' PGNN-dep-parser/ taoji@139.196.228.41:/home/taoji/data/Github/PGNN-Transformer/PGNN-dep-parser
# ssh taoji@139.196.228.41 -p 8020 -T < test.sh

# 8014
# rsync -avz -e 'ssh -p 8014' PGNN-dep-parser/ taoji@139.196.228.41:/home/taoji/data/Github/PGNN-Transformer/PGNN-dep-parser
# ssh taoji@139.196.228.41 -p 8014 -T < test.sh

# 2080ti
# rsync -avz -e 'ssh -p 26070' PGNN-dep-parser/ taoji@60.205.219.151:/home/taoji/data/PGNN-Transformer/PGNN-dep-parser
# ssh taoji@60.205.219.151 -p 26070 -T < test.sh
