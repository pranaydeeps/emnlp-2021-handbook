# New Transition Encoder
A Full Transition System Encoder for Dependency Parsing
