# Region-under-discussion-for-visual-dialog

## GWHist

Subset of history dependent questions of GuessWhat?!
The csv file contains the following data:

- question\_id: The unique identifier for the given question in the GuessWhat?! dataset.
- game\_id: Game ID of a given question.
- question: The history dependent question.

