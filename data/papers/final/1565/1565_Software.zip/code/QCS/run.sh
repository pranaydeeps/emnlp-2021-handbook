python3 -m utils.effectiveness \
    -breaking \
    -question_data data/cl1_dialogues.json \
    -from_gameplay \
    -out_fname rs_compute_val.json \
    -split test
