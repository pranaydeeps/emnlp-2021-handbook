OracleVisualData.py: option 1
OracleVisualData2.py: option 2

