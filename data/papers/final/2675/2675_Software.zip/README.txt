Get the code, pretrained model, and dataset at the following link:
* https://www.dropbox.com/sh/11742aqaq60iwol/AABaKHQrqkqGBg__uand68fSa?dl=0