import dynet as dy
from antu.io.datasets.single_task_dataset import SingleTaskDataset
from antu.io.ini_configurator import IniConfigurator

class Parser:

    def __init__(
        self,
        cfg: IniConfigurator,
        datasets: SingleTaskDataset,
        pc: dy.ParameterCollection,
        token_repre,
        encoder,
        decoder) -> None:
    """
    """
    self.encoder = encoder
    self.decoder = decoder
    self.cfg = cfg
    self.datasets = datasets
    self.pc = pc

    def __call__(self, batch_input):
