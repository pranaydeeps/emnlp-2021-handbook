# -*- coding: utf-8 -*-

from models.aagcn import AAGCN
from models.aagcn_bert import AAGCN_BERT