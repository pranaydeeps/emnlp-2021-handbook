python finetune.py --task localization --type pretrain --seed 2020 --logdir ./log/localization -b 4 -e 1 --n_gpu 1 --shift_table ./assign_token/frequency/localization_token_map_frequency.pkl
