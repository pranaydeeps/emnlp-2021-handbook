export USE_TORCH=1
task="splice"
epoch="2"
seed="2020"
python finetune.py --task $task \
	--type pretrain \
	--seed $seed \
	--logdir ./log/$task/ \
    --datadir ./data \
	-b 16 \
	-e $epoch \
    --save_step 1000 \
	--n_gpu 1

