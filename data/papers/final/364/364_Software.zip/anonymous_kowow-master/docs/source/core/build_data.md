# parlai.core.build_data
```{eval-rst}
.. automodule:: parlai.core.build_data
  :members:
```
