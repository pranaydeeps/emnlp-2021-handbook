# parlai.core.agents
```{eval-rst}
.. automodule:: parlai.core.agents
  :members:
```
