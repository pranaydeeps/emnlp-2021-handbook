# parlai.core.mutators
```{eval-rst}
.. automodule:: parlai.core.mutators
  :members:
```
