# parlai.core.worlds
```{eval-rst}
.. automodule:: parlai.core.worlds
  :members:
```
