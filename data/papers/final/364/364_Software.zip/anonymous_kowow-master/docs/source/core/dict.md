# parlai.core.dict
```{eval-rst}
.. automodule:: parlai.core.dict
  :members:
```
