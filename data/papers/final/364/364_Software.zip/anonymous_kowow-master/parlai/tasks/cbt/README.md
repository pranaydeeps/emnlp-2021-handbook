Task: Children's Book Test (CBT)
=================================
Description: Sentence completion given a few sentences as context from a children's book. From Hill et al., '16. 

Link: https://arxiv.org/abs/1511.02301

Tags: #CBT, #All, #Cloze

