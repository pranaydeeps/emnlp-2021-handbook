import json

data_path = 'valid.json'
save_path = 'valid_filtered.json'

def json_reader(path):
    with open(path, 'r') as f:
        data = json.load(f)
    return data

def json_saver(data, path):
    with open(path, 'w') as f:
        json.dump(data, f)

data = json_reader(data_path)

filted_data = []
max_len = 0
for sample in data:
    if sample['source'] != '':
        filted_data.append(sample)
        if len(sample['source'].split(' ')) > max_len :
            max_len = len(sample['source'].split(' '))

json_saver(filted_data, save_path)
print('original length:', len(data), 'after filtered:', len(filted_data))
        
