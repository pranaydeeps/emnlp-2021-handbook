import json

source_file = open('test.source.raw', 'w')
#target_file = open('train.target', 'w')
with open('test_filtered.json', "r") as f:
    instances = [json.loads(ln) for ln in f][0]

print(len(instances))

for instance in instances:
    source = instance['source']
    source_file.write("%s\n" % source)
