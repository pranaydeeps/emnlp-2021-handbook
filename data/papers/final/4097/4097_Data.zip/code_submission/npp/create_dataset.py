import json

source_file = open('test.source', 'w')
target_file = open('test.target', 'w')
with open('test.json', "r") as f:
    instances = [json.loads(ln) for ln in f][0]

print(len(instances))

for instance in instances:
    source = instance['source'] + "\t"
    index = 1
    for option in instance['options']:
        source += str(index) + ". " + option + " "
        index += 1
    source_file.write("generate next phrases of this sentence: %s\n" % source)
    target_file.write("%s\n" % instance['target'])
