Teacher Ratings for WorldTree V2 corpus. 

NOTE:

Raw ratings input by teachers were 1-4, where 0 means not rated.  (The paper describes this as 0-3, for simplicity). 

Ratings in the JSON file include both raw ratings (1-4), as well as a single integer relevance rating that is the sum of the rescaled scores (0-6).


Attribution:
Figure 2: “image: Freepik.com”. This figure has been designed using resources from Freepik.com
