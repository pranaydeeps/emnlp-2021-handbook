------------- README --------------

Dependencies: pytorch, keras, numpy

* code/metric_pipeline.sh contains the codes to do preprocessing necessary for the COSMic model.
* code/main.py contains the main function to train/test COSMic.
* code/model.py contains the model implementations of COSMic.
* code/dataloader.py contains functions to load the training data features generated from metric_pipeline.sh

How to run:

1. First run the metric_pipeline script
2. Train the model by calling the main function

*_*_*_*_*_*_* Data *_*_*_*_*_*_*_*
We provide 500 groundtruth captions for the COIN dataset under data/test_gt.tsv, the total dataset will be available at the final submission.