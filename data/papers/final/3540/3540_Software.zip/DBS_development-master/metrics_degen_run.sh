#!/bin/bash

# Change path (-file=) to the file for which you want to calculate the metrics

#python metrics_degen.py -file=results/50_keywordsets_eval/LinearQLog_noSq_deterministic_result_w_20.0_nBeams_1_nConcSent_1_nGenSent_90_nWordsPerSent_1_temperature_1.0.txt

