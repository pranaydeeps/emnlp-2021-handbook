from declutr.model import DeCLUTR
from declutr.encoder import Encoder
