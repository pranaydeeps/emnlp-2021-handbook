from declutr.losses.pytorch_metric_learning import (
    CrossBatchMemory,
    NTXentLoss,
    PyTorchMetricLearningLoss,
)
