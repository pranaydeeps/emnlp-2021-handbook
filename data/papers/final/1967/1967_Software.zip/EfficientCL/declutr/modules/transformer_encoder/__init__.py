from declutr.modules.transformer_encoder.bertencoder import (
    BertEncoder,
)
