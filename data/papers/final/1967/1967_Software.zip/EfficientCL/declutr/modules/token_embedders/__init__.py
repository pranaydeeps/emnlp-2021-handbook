from declutr.modules.token_embedders.pretrained_transformer_embedder_mlm import (
    PretrainedTransformerEmbedderMLM,
)
