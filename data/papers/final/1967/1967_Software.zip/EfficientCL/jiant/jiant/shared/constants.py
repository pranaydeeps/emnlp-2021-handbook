class PHASE:
    TRAIN = "train"
    VAL = "val"
    TEST = "test"
