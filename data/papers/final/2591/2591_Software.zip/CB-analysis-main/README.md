# CerealBar Analysis

This is the code for the paper "Analysis of Language Change in Collaborative Instruction Following", Anna Effenberger, Eva Yan, Rhia Singh, Alane Suhr, and Yoav Artzi. 

All analysis code can be found in `CB_analysis.ipynb`. `seniorgames_buckets.csv` contains data to assign games played by experienced players to community lifetime deciles. 
