# Copyright (c) Facebook, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from .wav2vec import *  # noqa
from .wav2vec2 import *  # noqa
from .wav2vec2_asr import *  # noqa
from .wav2bert import *
from .wav2bert_masked_predict_model import *
from .wav2bert_masked_predict_separate_fusion import *
from .onlybert import *
from .wav2bert_masked_predict_fusion_ctc import *
from .wav2bert_masked_predict_fusion_ctc2 import *
from .wav2bert_masked_predict_fusion_ce import *
from .wav2bert_masked_predict_fusion_ce2 import *
from .wav2bert_mask_predict_fusion_ctc_gate import *
from .wav2bert_mask_predict_fusion_ctc_gate2 import *
from .wav2bert_mask_predict_fusion_ce_gate import *
from .wav2bert_mask_predict_fusion_ce_gate2 import *
from .wav2bert_mask_predict_fusion_ctc_context import *
from .wav2bert_mask_predict_fusion_ce_context import *
from .wav2bert_mask_predict_fusion_two_way import *
from .wav2bert_mask_predict_fusion_two_way_to_input import *
from .wav2bert_mask_predict_fusion_ce_to_input import *
from .wav2bert_mask_predict_fusion_ctc_gate_to_input import *

from .wav2bert_mask_predict_fusion_ctc_gate_ctc_to_bert import *
from .wav2bert_mask_predict_fusion_two_way_gate_ctc_to_bert import *
from .wav2bert_mask_predict_fusion_ce_gate_ctc_to_bert import *
from .wav2bert_mask_predict_fusion_ctc_ctc_to_bert import *
from .wav2bert_mask_predict_fusion_ctc_gate_ctc_to_bert_fusion_v1 import *
from .wav2bert_mask_predict_fusion_ctc_gate_ctc_to_bert_fusion_v2 import *
from .wav2bert_mask_predict_fusion_two_way_ctc_to_bert import *
from .wav2bert_mask_predict_fusion_two_way_gate_ctc_to_bert_v2 import *
from .wav2bert_mask_predict_fusion_two_way_gate_ctc_to_bert_v3 import *
from .wav2bert_mask_predict_fusion_two_way_gate_ctc_to_bert_pe import *

from .wav2bert_ctc_cif_ce import *
from .wav2bert_ctc_cif_fast import *

from .wav2vec2_cif_bert import *