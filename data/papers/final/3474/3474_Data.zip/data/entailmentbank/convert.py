
import json
import sys
import random

def normalize(sent):
    return sent.replace(' ,',',').replace(' \'', '\'')+'.'

if __name__ == "__main__":
    with open(sys.argv[1], encoding='utf8') as source_file:
        with open(sys.argv[2], mode='w', encoding='utf8') as out_file:
            for l in source_file:
                source_ex = json.loads(l)
                for step in source_ex['proof'].split('; ')[:-1]:
                    step_inputs, step_output = step.split(' -> ')
                    if step_output == 'hypothesis':
                        step_output = source_ex['hypothesis']
                    else:
                        step_output = step_output.split(': ', maxsplit=1)[1]
                    ex = [
                        normalize(source_ex['meta']['triples'].get(sent_id) or source_ex['meta']['intermediate_conclusions'][sent_id]) \
                        for sent_id in step_inputs.split(' & ')
                    ]
                    random.shuffle(ex)
                    ex.append(normalize(step_output))
                    out_file.write(json.dumps(ex))
                    out_file.write('\n')

