import sys
import json
import os.path

if __name__ == "__main__":
    train_lines_clean = []
    with open(sys.argv[1], encoding='utf8') as train_file:
        with open(sys.argv[2], encoding='utf8') as dev_file:
            dev_exs = [json.loads(l) for l in dev_file]
            dev_targets = {dev_ex[-1] for dev_ex in dev_exs}
            dev_inputs = {frozenset(dev_ex[:-1]) for dev_ex in dev_exs}
            for l in train_file:
                train_ex = json.loads(l)
                if (train_ex[-1] not in dev_targets) and (frozenset(train_ex[:-1]) not in dev_inputs):
                    train_lines_clean.append(l)
    with open(os.path.splitext(sys.argv[1])[0]+'_clean.jsonl', mode='w', encoding='utf8') as out_file:
        for l in train_lines_clean:
            out_file.write(l)