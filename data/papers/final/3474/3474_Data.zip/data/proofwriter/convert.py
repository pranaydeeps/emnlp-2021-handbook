import json
import sys
import random

if __name__ == "__main__":
    source_exs = []
    for source_file in sys.argv[1:-1]:
        with open(source_file, encoding='utf8') as f:
            source_exs.extend(json.loads(l) for l in f)
    with open(sys.argv[-1], mode='w', encoding='utf8') as out_file:
        for source_ex in source_exs:
            for inference in source_ex['allInferences']:
                strip_chars = '[]()'
                proofs_clean = inference['proofs']
                for strip_char in strip_chars:
                    proofs_clean = proofs_clean.replace(strip_char, '')
                for proof in proofs_clean.split(' OR '):
                    triples_joined, rule = proof.split(' -> ')
                    triples = triples_joined.split(' ')
                    ex = []
                    for triple in triples:
                        ex.append(source_ex['triples'][triple]['text'])
                    ex.append(source_ex['rules'][rule]['text'])
                    random.shuffle(ex)
                    ex.append(inference['text'])
                    out_file.write(json.dumps(ex))
                    out_file.write('\n')

