# Readme

This supplemental material provides additional information that may be of interest to reviewers who wish to further understand our methods. In particular:

- The ```keyword_lists``` directory displays the keywords used to select out tweets from survey respondents for each of the four targets
- We also provide the ```R``` code used to produce all plots in the paper, see ```emnlp_results.R```. As discussed in the article, we do not have permission to release survey data, but we do provide enough data to replicate all figures in the paper except for Figure 3.  Data to do so is provided in the ```data``` directory
- The file ```ann_example.png``` 
