package cn.edu.nju.websoft.artime.semantic.constant

trait ValueForm {
}
