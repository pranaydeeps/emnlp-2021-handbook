package cn.edu.nju.websoft.artime.utils

case class ReverseNodeIndex[NodeType](
  upperNode: NodeType,
  position: Int
)
