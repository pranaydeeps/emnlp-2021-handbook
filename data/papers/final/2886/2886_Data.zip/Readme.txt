Datasets:
    The datasets used in our evaluations. 
    The correction of none TimeML annotations in Tweets are recorded in the modification.log files in corresponding diectories.
    Evaluate SUTime on TempEval-3 needs to delete <MAKEINSTANCE> tags from the testsets, which does not affect the result of normalization. The corresponding files are in diectory '/Datasets/TempEval-3/TempEval-3 testset only for SUTime'

Results:
    The evaluation results corresponds to the main results in our paper (i.e, Table 4 and Table 5).

CandidateRules:
    The canddiate rules ranked by their frequency. (Among the conflict rules, only the first one will be used for normalization.)

ExpertRules:
    The expert rules for implementing ARTime+H




    
