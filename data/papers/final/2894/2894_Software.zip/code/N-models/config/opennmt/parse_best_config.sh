#!/bin/bash
var_rewrite="rel" 			 # options: {rel, abs, none}
