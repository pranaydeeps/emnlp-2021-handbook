Contains code you can use to evaluate ADELE on different languages (de, en, es, hr, it, ru, tr).
