
## Dependencies
- Python 3.6+
- [PyTorch](http://pytorch.org/) 1.0+


## Running the code 

### Usage
```
wn18rr:

CUDA_VISIBLE_DEVICES=0 python -u codes/runs.py --do_train --do_valid --do_test --data_path ./data/wn18rr/ --model HypBallE -n 1024 -b 256 -d 512 -g 6.0 -a 0.5 -lr 0.0001 --max_steps 80000 -save models/HypBallE_wn18rr_0 --test_batch_size 8 --cuda

FB15k-237:

CUDA_VISIBLE_DEVICES=1 python -u codes/runs.py --do_train --do_valid --do_test --data_path ./data/FB15k-237/ --model HypBallE -n 1024 -b 256 -d 1000 -g 9.0 -a 1.0 -lr 0.0001 --max_steps 80000 -save models/HypBallE_FB15k-237_0 --test_batch_size 8 --cuda

YAGO3-10:

CUDA_VISIBLE_DEVICES=2 python -u codes/runs.py --do_train --do_valid --do_test --data_path ./data/YAGO3-10/ --model HypBallE -n 512 -b 256 -d 512 -g 24.0 -a 1.0 -lr 0.002 --max_steps 180000 -save models/HypBallE_YAGO3-10_0 --test_batch_size 8 --cuda

```
