from textblob_de import TextBlobDE as TextBlob
import json, requests
url = 'http://127.0.0.1:5000'


noun = 0
adjective = 0
DT = 0
verb = 0
interjection = 0
conjunction = 0
preposition = 0
adverb = 0
pronoun = 0
CD = 0
FW = 0

PoS_noun = 0
PoS_adjective = 0
PoS_DT = 0
PoS_verb = 0
PoS_interjection = 0
PoS_conjunction = 0
PoS_preposition = 0
PoS_adverb = 0
PoS_pronoun = 0
PoS_CD = 0
PoS_FW = 0

with open("machine_translation.txt") as textfile1, open("ground_truth_annotations.txt") as textfile2, open("source.txt") as textfile3:
    for target, gold_tags, source in zip(textfile1, textfile2, textfile3):
        f = open("errorModel.txt", "a")
        target = target.strip()
        source = source.strip()
        data = json.dumps({'source': source, 'mt': target})
        send_request = requests.post(url, data)

        label_predictions = []
        for i in range(len(send_request.json()['results']['qualityLabels'])):
            label_predictions.append(send_request.json()['results']['qualityLabels'][i][1])
        gold_tags = gold_tags.strip()
        blob = TextBlob(target)
        count = 1

        word_level_predictions = []
        for part in gold_tags.split():

            if count % 2 == 0:
                word_level_predictions.append(part)
            count += 1
        word_level_predictions.append('OK')
        finalArray = []
	#Count the total number of each part of speech.
	for i in range(0, len(blob.tags)):
	    if blob.tags[i][1] == 'NN' or  blob.tags[i][1] == 'NNS' or blob.tags[i][1] == 'NNP':
	        PoS_noun += 1
	    elif blob.tags[i][1] == 'VB' or blob.tags[i][1] == 'VBD' or blob.tags[i][1] == 'VBN':
	        PoS_verb += 1
	    elif blob.tags[i][1] == 'DT' or blob.tags[i][1] == 'WDT':
            	PoS_DT += 1
	    elif blob.tags[i][1] == 'TO':
	    	PoS_preposition += 1
		PoS_adverb += 1
	    elif blob.tags[i][1] == 'JJ':
		PoS_adjective += 1
            elif blob.tags[i][1] == 'IN':
		PoS_preposition += 1
		PoS_interjection += 1
            elif blob.tags[i][1] == 'CC':
		PoS_conjunction += 1
            elif blob.tags[i][1] == 'RB' or blob.tags[i][1] == 'WRB' or blob.tags[i][1] == 'RP':
		PoS_adverb += 1
            elif blob.tags[i][1] == 'PRP' or blob.tags[i][1] == 'PRP$':
                PoS_pronoun += 1
	    elif blob.tags[i][1] == 'CD':
		PoS_CD += 1
            else:
		PoS_FW += 1

	# Capture the errors
        for i in range(0, len(blob.tags)):
            if word_level_predictions[i] != label_predictions[i]:
                if blob.tags[i][1] == 'NN' or  blob.tags[i][1] == 'NNS' or blob.tags[i][1] == 'NNP':
                    noun += 1

                elif blob.tags[i][1] == 'VB' or blob.tags[i][1] == 'VBD' or blob.tags[i][1] == 'VBN':
                    verb += 1

                elif blob.tags[i][1] == 'DT' or blob.tags[i][1] == 'WDT':
                    DT += 1
                    
                elif blob.tags[i][1] == 'TO':
                    adverb += 1
                    preposition +=1
                    
                elif blob.tags[i][1] == 'JJ':
                    adjective += 1
                    
                elif blob.tags[i][1] == 'IN':
                    interjection += 1
                    preposition += 1
                    
                elif blob.tags[i][1] == 'CC':
                    conjunction += 1
                    
                elif blob.tags[i][1] == 'RB' or blob.tags[i][1] == 'WRB' or blob.tags[i][1] == 'RP':
                    adverb += 1
                    
                elif blob.tags[i][1] == 'PRP' or blob.tags[i][1] == 'PRP$':
                    pronoun += 1
                    
                elif blob.tags[i][1] == 'CD':
                    CD += 1
                    
                else:
                    FW += 1
                    
            tuple_ = (blob.tags[i][0], blob.tags[i][1], word_level_predictions[i])
            finalArray.append(tuple_)

        print('noun:', noun/PoS_noun)
        print('verb', verb/PoS_verb)
        print('DT', DT/PoS_DT)
        print('adjective', adjective/PoS_adjective)
        print('interjection', interjection/PoS_interjection)
        print('preposition', preposition/PoS_preposition)
        print('pronoun', pronoun/PoS_pronoun)
        print('cardinal', CD/PoS_CD)
        print('adverb', adverb/PoS_adverb)
        print('foreign words', FW/PoS_FW)
        f.write(str(finalArray) + '\n')
        f.close()