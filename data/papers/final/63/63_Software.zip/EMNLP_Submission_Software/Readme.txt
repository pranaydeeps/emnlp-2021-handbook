In this readme file, you can find information about the contents of the folders

1_Real_QE_Model
In this folder you can find the following:
- model_server.py: This script spawns a live server that returns the predictions when the application sends data to the server. It utilizes the pre-trained QEBrain model trained on the training set of WMT 2018's QE shared task and is used to generate predictions on the MT output used in the user study.

2_Artificial_data_generation 
In this folder you can find the following:
- pre_analysis.py: This script utilizes machine_translation.txt, ground_truth_annotations.txt and source.txt to generate conditional probabilities of each part of speech. It assumes that there is a QE model server running on 'http://127.0.0.1:5000'. Otherwise, the script won't execute.
- fake_data_generation.py: This script utilizes ground_truth_annotations.txt to generate annotations on machine_translation.txt by the simulated QE models by flipping the ground truth annotations by the error distribution.

