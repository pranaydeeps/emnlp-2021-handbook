In this readme file, you can find information about the contents of the folders

1_Data
This folder contains the following:
Experiment_Text: This subfolder contains the data used in the main experiment and also the corresponding reference translations.
Editing_Duration, Subjective_Ratings, TER and Visualization_Preferrence: These subfolders contains extracted data, namely editing duration, subjective ratings, final translation quality and preferred visualization scheme from all the participants in the user study. It is basically the data used for generating the plots in the paper.

 
