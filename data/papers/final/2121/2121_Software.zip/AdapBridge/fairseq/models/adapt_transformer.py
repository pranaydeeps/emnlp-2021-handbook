# Copyright (c) Facebook, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
import numpy
import nltk
import random
import math
from typing import Any, Dict, List, Optional, Tuple
import pdb

import torch
import torch.nn as nn
import torch.nn.functional as F
from fairseq import options, utils
from fairseq.models import (
    FairseqEncoder,
    FairseqEncoderDecoderModel,
    FairseqIncrementalDecoder,
    register_model,
    register_model_architecture,
)
from fairseq.models.fairseq_encoder import EncoderOut
from fairseq.modules import (
    AdaptiveSoftmax,
    LayerNorm,
    PositionalEmbedding,
    SinusoidalPositionalEmbedding,
    TransformerDecoderLayer,
    TransformerEncoderLayer,
)
from torch import Tensor

DEFAULT_MAX_SOURCE_POSITIONS = 1024
DEFAULT_MAX_TARGET_POSITIONS = 1024


@register_model("adapt_transformer")
class TransformerModel(FairseqEncoderDecoderModel):
    @classmethod
    def hub_models(cls):
        return {}

    pad_idx = 1
    bos_idx = 2

    def __init__(self, args, encoder, decoder,  generator_length_constrain=None,generator_beam_search=None,decoder_embed_tokens=None):
        super().__init__(encoder, decoder)
        self.args = args
        self.supports_align_args = False
        self.use_word_oracle = args.use_word_level_oracles
        self.use_sentence_oracle = args.use_sentence_level_oracles
        self.generator_length_constrain = generator_length_constrain
        self.generator_beam_search = generator_beam_search
        self.updates = 0
        self.epoch = 0
        self.decay_k = args.decay_k
        self.epoch_decay = args.use_epoch_numbers_decay
        self.use_greed_gumbel_noise = args.use_greed_gumbel_noise
        self.gumbel_noise = args.gumbel_noise
        self.use_bleu_gumbel_noise = args.use_bleu_gumbel_noise
        self.probs = 1
        self.embedding = decoder_embed_tokens
        self.train_adapt_type = args.train_adapt_type
        self.use_adapt_n_gram = args.use_adapt_n_gram
        self.adapt_n_gram_number = args.adapt_n_gram_number
        if self.use_adapt_n_gram:
           print('*********************use_adapt_n_gram**********************'+str(self.adapt_n_gram_number))
        if self.train_adapt_type==0:
            print("****************train_adapt_0_sentence***********")
        elif self.train_adapt_type==1:
            print("****************train_adapt_1_token***********")
        elif self.train_adapt_type==2:
            print("****************train_adapt_2_sentence_token***********")
        else:
            print("****************train_adapt_3_base***********")

    @staticmethod
    def add_args(parser):
        """Add model-specific arguments to the parser."""
        # fmt: off
        parser.add_argument('--activation-fn',
                            choices=utils.get_available_activation_fns(),
                            help='activation function to use')
        parser.add_argument('--dropout', type=float, metavar='D',
                            help='dropout probability')
        parser.add_argument('--attention-dropout', type=float, metavar='D',
                            help='dropout probability for attention weights')
        parser.add_argument('--activation-dropout', '--relu-dropout', type=float, metavar='D',
                            help='dropout probability after activation in FFN.')
        parser.add_argument('--encoder-embed-path', type=str, metavar='STR',
                            help='path to pre-trained encoder embedding')
        parser.add_argument('--encoder-embed-dim', type=int, metavar='N',
                            help='encoder embedding dimension')
        parser.add_argument('--encoder-ffn-embed-dim', type=int, metavar='N',
                            help='encoder embedding dimension for FFN')
        parser.add_argument('--encoder-layers', type=int, metavar='N',
                            help='num encoder layers')
        parser.add_argument('--encoder-attention-heads', type=int, metavar='N',
                            help='num encoder attention heads')
        parser.add_argument('--encoder-normalize-before', action='store_true',
                            help='apply layernorm before each encoder block')
        parser.add_argument('--encoder-learned-pos', action='store_true',
                            help='use learned positional embeddings in the encoder')
        parser.add_argument('--decoder-embed-path', type=str, metavar='STR',
                            help='path to pre-trained decoder embedding')
        parser.add_argument('--decoder-embed-dim', type=int, metavar='N',
                            help='decoder embedding dimension')
        parser.add_argument('--decoder-ffn-embed-dim', type=int, metavar='N',
                            help='decoder embedding dimension for FFN')
        parser.add_argument('--decoder-layers', type=int, metavar='N',
                            help='num decoder layers')
        parser.add_argument('--decoder-attention-heads', type=int, metavar='N',
                            help='num decoder attention heads')
        parser.add_argument('--decoder-learned-pos', action='store_true',
                            help='use learned positional embeddings in the decoder')
        parser.add_argument('--decoder-normalize-before', action='store_true',
                            help='apply layernorm before each decoder block')
        parser.add_argument('--share-decoder-input-output-embed', action='store_true',
                            help='share decoder input and output embeddings')
        parser.add_argument('--share-all-embeddings', action='store_true',
                            help='share encoder, decoder and output embeddings'
                                 ' (requires shared dictionary and embed dim)')
        parser.add_argument('--no-token-positional-embeddings', default=False, action='store_true',
                            help='if set, disables positional embeddings (outside self attention)')
        parser.add_argument('--adaptive-softmax-cutoff', metavar='EXPR',
                            help='comma separated list of adaptive softmax cutoff points. '
                                 'Must be used with adaptive_loss criterion'),
        parser.add_argument('--adaptive-softmax-dropout', type=float, metavar='D',
                            help='sets adaptive softmax dropout for the tail projections')
        # args for "Cross+Self-Attention for Transformer Models" (Peitz et al., 2019)
        parser.add_argument('--no-cross-attention', default=False, action='store_true',
                            help='do not perform cross-attention')
        parser.add_argument('--cross-self-attention', default=False, action='store_true',
                            help='perform cross+self-attention')
        parser.add_argument('--layer-wise-attention', default=False, action='store_true',
                            help='perform layer-wise attention (cross-attention or cross+self-attention)')
        # args for "Reducing Transformer Depth on Demand with Structured Dropout" (Fan et al., 2019)
        parser.add_argument('--encoder-layerdrop', type=float, metavar='D', default=0,
                            help='LayerDrop probability for encoder')
        parser.add_argument('--decoder-layerdrop', type=float, metavar='D', default=0,
                            help='LayerDrop probability for decoder')
        parser.add_argument('--encoder-layers-to-keep', default=None,
                            help='which layers to *keep* when pruning as a comma-separated list')
        parser.add_argument('--decoder-layers-to-keep', default=None,
                            help='which layers to *keep* when pruning as a comma-separated list')
        parser.add_argument('--layernorm-embedding', action='store_true',
                            help='add layernorm to embedding')
        parser.add_argument('--no-scale-embedding', action='store_true',
                            help='if True, dont scale embeddings')
        # oracle arguments
        parser.add_argument('--use-sentence-level-oracles', action='store_true', default=False,
                            help='use sentences level oracles')
        parser.add_argument('--use-word-level-oracles', action='store_true', default=False,
                            help='use word level oracles')
        parser.add_argument('--decay-k', type=float, metavar='D', default=3000,
                            help='decay k')
        parser.add_argument('--use-epoch-numbers-decay', action='store_true', default=False,
                            help='probability decay by epoch number')
        parser.add_argument('--use-greed-gumbel-noise', action='store_true', default=False,
                            help='select word with gumbel noise')
        parser.add_argument('--gumbel-noise', type=float, metavar='D', default=0.5,
                            help='word noise')
        parser.add_argument('--use-bleu-gumbel-noise', action='store_true', default=False,
                            help='generate sentence with gumbel noise')
        parser.add_argument('--oracle-search-beam-size', type=int, metavar='N', default=4,
                            help='generate oracle sentence beam size')
        parser.add_argument('--train_adapt_type', type=int, metavar='N', default=0,
                            help='train adapt model type 0: sentence 1:token 2:token-sentence')

        parser.add_argument('--use_adapt_n_gram', action='store_true', default=False,
                              help='use n-gram')
        parser.add_argument('--adapt_n_gram_number', type=int, metavar='D', default=3,help='n-gram number default 3')
    @classmethod
    def build_model(cls, args, task):
        """Build a new model instance."""

        # make sure all arguments are present in older models
        base_architecture(args)

        if args.encoder_layers_to_keep:
            args.encoder_layers = len(args.encoder_layers_to_keep.split(","))
        if args.decoder_layers_to_keep:
            args.decoder_layers = len(args.decoder_layers_to_keep.split(","))

        if getattr(args, "max_source_positions", None) is None:
            args.max_source_positions = DEFAULT_MAX_SOURCE_POSITIONS
        if getattr(args, "max_target_positions", None) is None:
            args.max_target_positions = DEFAULT_MAX_TARGET_POSITIONS

        src_dict, tgt_dict = task.source_dictionary, task.target_dictionary
        generator_beam_search = None
        generator_length_constrain = None
        # 如果使用sentence 级别的预测信息
        # if args.use_sentence_level_oracles:
        from fairseq.sequence_generator import SequenceGenerator
        import fairseq.search as search
        # 搜索策略 为强制长度
        # pdb.set_trace()
        search_strategy_constrain = search.LengthConstrainedBeamSearch(tgt_dict, min_len_a=1,
                                                                 min_len_b=0,
                                                                 max_len_a=1,
                                                                 max_len_b=0, )
        generator_length_constrain = SequenceGenerator(tgt_dict, beam_size=args.oracle_search_beam_size, match_source_len=False,
                                        max_len_a=1, max_len_b=100, search_strategy=search_strategy_constrain)

        search_strategy_beam_search = search.BeamSearch(tgt_dict)
        # 得到生成器
        generator_beam_search = SequenceGenerator(tgt_dict, beam_size=args.oracle_search_beam_size, match_source_len=False,
                                        max_len_a=1, max_len_b=100, search_strategy=search_strategy_beam_search)
        if args.share_all_embeddings:
            if src_dict != tgt_dict:
                raise ValueError("--share-all-embeddings requires a joined dictionary")
            if args.encoder_embed_dim != args.decoder_embed_dim:
                raise ValueError(
                    "--share-all-embeddings requires --encoder-embed-dim to match --decoder-embed-dim"
                )
            if args.decoder_embed_path and (
                    args.decoder_embed_path != args.encoder_embed_path
            ):
                raise ValueError(
                    "--share-all-embeddings not compatible with --decoder-embed-path"
                )
            encoder_embed_tokens = cls.build_embedding(
                args, src_dict, args.encoder_embed_dim, args.encoder_embed_path
            )
            decoder_embed_tokens = encoder_embed_tokens
            args.share_decoder_input_output_embed = True
        else:
            encoder_embed_tokens = cls.build_embedding(
                args, src_dict, args.encoder_embed_dim, args.encoder_embed_path
            )
            decoder_embed_tokens = cls.build_embedding(
                args, tgt_dict, args.decoder_embed_dim, args.decoder_embed_path
            )
        # self.embeding = 

        encoder = cls.build_encoder(args, src_dict, encoder_embed_tokens)
        decoder = cls.build_decoder(args, tgt_dict, decoder_embed_tokens)

        return cls(args, encoder, decoder, generator_length_constrain,generator_beam_search,decoder_embed_tokens)# 把词嵌入矩阵也传进入，这样模型可以用到

    @classmethod
    def build_embedding(cls, args, dictionary, embed_dim, path=None):
        num_embeddings = len(dictionary)
        padding_idx = dictionary.pad()

        emb = Embedding(num_embeddings, embed_dim, padding_idx)
        # if provided, load from preloaded dictionaries
        if path:
            embed_dict = utils.parse_embedding(path)
            utils.load_embedding(embed_dict, dictionary, emb)
        return emb

    @classmethod
    def build_encoder(cls, args, src_dict, embed_tokens):
        return TransformerEncoder(args, src_dict, embed_tokens)

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        return TransformerDecoder(
            args,
            tgt_dict,
            embed_tokens,
            no_encoder_attn=getattr(args, "no_cross_attention", False),
        )

    def set_num_updates(self, num_updates):
        self.updates = num_updates

    def set_epoch(self, epoch):
        self.epoch = epoch
        if (self.epoch_decay is True) :# 如果是根据训练轮数进行衰减
            self.decay_prob(epoch-62,or_type=3, k=self.decay_k) #这里决定了要多大概率进行递归训练
            print('Swith to epoch {}, prob. -> {}'.format(epoch, self.probs))

    def decay_prob(self, i, or_type=3, k=3000):# 选择衰减的方式
        if or_type == 1:  # Linear decay
            or_prob_begin, or_prob_end = 1., 0.1
            or_decay_rate = (or_prob_begin - or_prob_end) / 25.
            # ss_decay_rate = 0.035
            prob = or_prob_begin - (or_decay_rate * i)
            if prob < or_prob_end:
                prob_i = or_prob_end
                print('[Linear] schedule sampling probability do not change {}'.format(prob_i))
            else:
                prob_i = prob
                print('[Linear] decay schedule sampling probability to {}'.format(prob_i))

        elif or_type == 2:  # Exponential decay
            prob_i = numpy.power(k, i)
            print('[Exponential] decay schedule sampling probability to {}'.format(prob_i))

        elif or_type == 3:  # Inverse sigmoid decay
            prob_i = k / (k + numpy.exp((i / k)))
            # print('[Inverse] decay schedule sampling probability to {}'.format(prob_i))
            # pdb.set_trace()
        self.probs = prob_i
        return prob_i

    def get_probs(self):
        return self.probs

    # # 获取词语级别的预测token信息
    # def get_word_orcale_tokens(self, pred_logits, prev_output_tokens, epsilon=1e-6):
    #     B, L = prev_output_tokens.size()
    #     # B x L x V
    #     if self.use_greed_gumbel_noise:
    #         pred_logits.data.add_(-torch.log(-torch.log(torch.Tensor(
    #             pred_logits.size()).to(pred_logits).uniform_(0, 1) + epsilon) + epsilon)) / self.gumbel_noise
    #     pred_tokens = torch.max(pred_logits, dim=-1)[1]# 得到预测的单词
    #     bos_idx = prev_output_tokens[0, 0]
    #     # pred_tokens = torch.cat([(bos_idx * torch.ones((B, 1))).to(pred_tokens), pred_tokens], dim=1)[:, :-1]
    #     # 将预测的单词拼接到后面
    #     pred_tokens = torch.cat([bos_idx * torch.ones((B, 1), device=pred_tokens.device, dtype=torch.int64), pred_tokens], dim=1)[:, :-1]
    #     sample_gold_prob = self.probs if self.epoch_decay else self.decay_prob(self.updates, k=self.decay_k)
    #     sample_gold_prob = sample_gold_prob * torch.ones_like(prev_output_tokens, dtype=torch.float32)# 获取groundtruth的概率
    #     sample_gold_mask = torch.bernoulli(sample_gold_prob).long()

    #     return prev_output_tokens * sample_gold_mask + pred_tokens * (1 - sample_gold_mask)# 分别对二者进行掩盖相加
    @torch.no_grad()
    def get_prev_tokens(self, pred_logits, prev_output_tokens,oracle_or_groundtruth, epsilon=1e-6):
        B, L = prev_output_tokens.size()
        # B x L x V
        pred_tokens = torch.max(pred_logits, dim=-1)[1]# 从输出的概率密度上得到预测的单词
        # pdb.set_trace() 
        bos_idx = prev_output_tokens[0, 0]# 第一个位置也是句子的结束token
        # 意思是在第一个位置上添加上句子结束的标志 主要是为了和prev_output_tokens对齐
        pred_tokens = torch.cat([bos_idx * torch.ones((B, 1), device=pred_tokens.device, dtype=torch.int64), pred_tokens], dim=1)[:, :-1] # 事实上真正的分数应该从这里出 只有这样 才能使其对齐
        # pdb.set_trace()
        self.train()
        # oracle_or_groundtruth 决定了当前这个位置是使用哪个地方生成的词
        return prev_output_tokens * oracle_or_groundtruth + pred_tokens * (1 - oracle_or_groundtruth)# 分别对二者进行掩盖相加
        # return prev_output_tokens * sample_gold_mask + pred_tokens * (1 - sample_gold_mask)# 分别对二者进行掩盖相加

    def compute_sentence_bleu(self, pred, ref):
        pre_str = [str(i) for i in pred]# 直接使用token id进行bleu值的计算
        ref_str = [str(i) for i in ref]# 参考句子
        bleu = nltk.translate.bleu_score.sentence_bleu([ref_str], pre_str)
        return bleu


    @torch.no_grad()
    def get_oracle_or_groundtruth(self, prev_output_tokens, src_tokens, src_lengths, target):
        bos_idx = prev_output_tokens[0, 0]# 获取句子结尾idx
        B, L = prev_output_tokens.size()
        sample = {}
        sample['net_input'] = {}
        sample['net_input']['src_tokens'] = src_tokens
        sample['net_input']['src_lengths'] = src_lengths
        noise = None
        if self.use_bleu_gumbel_noise:
            noise = self.gumbel_noise
        # 直接使用生成器得到输出结果
        out = self.generator_beam_search.generate([self], sample, target, noise=noise)
        oracle_or_groundtruth = torch.ones_like(target)# batch size，sentence length，hidden size
        i = 0
        # pdb.set_trace()
        for x, t in zip(out, target):
            tmp_max = 0
            best_item = None
            for item in x:# 计算bleu值，选取较高的句子
                bleu = self.compute_sentence_bleu(item['tokens'].cpu().numpy().tolist(), t.cpu().numpy().tolist())
                if bleu > tmp_max:
                    best_item = item
                    tmp_max = bleu
            # pdb.set_trace()
            target_embedding = self.embedding(t)
            oracle_embedding = self.embedding(best_item['tokens'])
            if self.use_adapt_n_gram:
               target_embedding = self.get_n_gram(target_embedding,self.adapt_n_gram_number)
               oracle_embedding = self.get_n_gram(oracle_embedding,self.adapt_n_gram_number)
            target_embedding_norm = target_embedding / target_embedding.norm(dim=1)[:, None]# 先进行归一化，要不然得到并不是真正的相似度矩阵
            oracle_embedding_norm = oracle_embedding / oracle_embedding.norm(dim=1)[:, None]
            similar_matrix = torch.mm(target_embedding_norm,oracle_embedding_norm.T)# 获取相似度矩阵
            similar_max = similar_matrix.max(1)[0] # 按行取最大值,获取该位置的词是否该被替换
            similar_threshold = similar_max<0.85 # 比这个小的设置为1，说明这个位置还不够好，表示仍然使用groundtruth，比其大的设置为0，表示使用oracle
            oracle_or_groundtruth[i,:] = similar_threshold.long()
            i+=1
        # 需要向前挪动一位 这样才能和prev_output_tokens对齐
        oracle_or_groundtruth = torch.cat([0 * torch.ones((B, 1), device=prev_output_tokens.device, dtype=torch.int64),oracle_or_groundtruth], dim=1)[:, :-1]
        # pdb.set_trace()
        #self.train()
        return oracle_or_groundtruth # 返回每个位置需要采取的训练方式
    @torch.no_grad()
    def get_n_gram(self,emd,n_gram=3):
        pad = n_gram//2 # gram最好是奇数
        emd_c = emd.clone()
        for i in range(pad,len(emd)-pad):
            #pdb.set_trace()
            emd[i]=sum(emd_c[i-pad:i+pad+1])/n_gram
        return emd

    @torch.no_grad()
    def train_adapt_1_token(self, pred_logits, prev_output_tokens, epsilon=1e-6):
        B, L = prev_output_tokens.size()
        if self.use_greed_gumbel_noise:
            pred_logits.data.add_(-torch.log(-torch.log(torch.Tensor(
                pred_logits.size()).to(pred_logits).uniform_(0, 1) + epsilon) + epsilon)) / self.gumbel_noise
        # pred_logits B x L x V
        pred_tokens = torch.max(pred_logits, dim=-1)[1]# 从输出的概率密度上得到预测的单词
        bos_idx = prev_output_tokens[0, 0]# 第一个位置也是句子的结束token
        # 意思是在第一个位置上添加上句子结束的标志 主要是为了和prev_output_tokens对齐
        pred_tokens = torch.cat([bos_idx * torch.ones((B, 1), device=pred_tokens.device, dtype=torch.int64), pred_tokens], dim=1)[:, :-1] # 事实上真正的分数应该从这里出 只有这样 才能使其对齐
        oracle_or_groundtruth = torch.ones_like(prev_output_tokens)# batch size，sentence length，hidden size
        for i in range(len(prev_output_tokens)):
            target_embedding = self.embedding(prev_output_tokens[i]).detach()
            oracle_embedding = self.embedding(pred_tokens[i]).detach()
            #pdb.set_trace()
            if self.use_adapt_n_gram:
                target_embedding = self.get_n_gram(target_embedding,self.adapt_n_gram_number)
                oracle_embedding = self.get_n_gram(oracle_embedding,self.adapt_n_gram_number)
            target_embedding_norm = target_embedding / target_embedding.norm(dim=1)[:, None]# 先进行归一化，要不然得到并不是真正的相似度矩阵
            oracle_embedding_norm = oracle_embedding / oracle_embedding.norm(dim=1)[:, None]
            similar_matrix = torch.mm(target_embedding_norm,oracle_embedding_norm.T)# 获取相似度矩阵
            # pdb.set_trace()
            similar_max = similar_matrix.max(0)[0] # 按行取最大值,获取该位置的词是否该被替换 改成按列取最大值
            prob = self.decay_prob(self.epoch-32,or_type=3,k=self.decay_k)
            beta = 0.9+0.1(1-prob)# 随着alpha变大
            similar_threshold = similar_max<beta # 比这个小的设置为1，说明这个位置还不够好，表示仍然使用groundtruth，比其大的设置为0，表示使用oracle
            oracle_or_groundtruth[i,:] = similar_threshold.long()
            # pdb.set_trace()
        #pdb.set_trace()
        #self.train()
        # oracle_or_groundtruth 决定了当前这个位置是使用哪个地方生成的词
        return prev_output_tokens * oracle_or_groundtruth + pred_tokens * (1 - oracle_or_groundtruth)# 分别对二者进行掩盖相加


    @torch.no_grad()
    def train_adapt_0_sentence(self, prev_output_tokens, src_tokens, src_lengths, target):
        bos_idx = prev_output_tokens[0, 0]# 获取句子结尾idx
        B, L = prev_output_tokens.size()
        sample = {}
        sample['net_input'] = {}
        sample['net_input']['src_tokens'] = src_tokens
        sample['net_input']['src_lengths'] = src_lengths
        noise = None
        if self.use_bleu_gumbel_noise:
            noise = self.gumbel_noise
        # 直接使用生成器得到输出结果
        out = self.generator_length_constrain.generate([self], sample, target, noise=noise)
        i = 0
        # pdb.set_trace()
        for x, t in zip(out, target):
            tmp_max = 0
            best_item = None
            for item in x:# 计算bleu值，选取较高的句子
                bleu = self.compute_sentence_bleu(item['tokens'].cpu().numpy().tolist(), t.cpu().numpy().tolist())
                if bleu > tmp_max:
                    best_item = item
                    tmp_max = bleu
            target_embedding = self.embedding(t)
            oracle_embedding = self.embedding(best_item['tokens'])
            if self.use_adapt_n_gram:
                target_embedding = self.get_n_gram(target_embedding,self.adapt_n_gram_number)
                oracle_embedding = self.get_n_gram(oracle_embedding,self.adapt_n_gram_number)
            target_embedding_norm = target_embedding / target_embedding.norm(dim=1)[:, None]# 先进行归一化，要不然得到并不是真正的相似度矩阵
            oracle_embedding_norm = oracle_embedding / oracle_embedding.norm(dim=1)[:, None]
            similar_matrix = torch.mm(target_embedding_norm,oracle_embedding_norm.T)# 获取相似度矩阵
            similar_max = similar_matrix.max(1)[0] # 按行取最大值,获取该位置的词是否该被替换
            similar_threshold = similar_max<0.85 # 比这个小的设置为1，说明这个位置还不够好，表示仍然使用groundtruth，比其大的设置为0，表示使用oracle
            oracle_or_groundtruth= similar_threshold.long()
            pred_len = len(best_item['tokens'])
            # if sum((prev_output_tokens[i][1:pred_len]!=t[:pred_len-1]).long())!=0:
            #     print('do not same')
            #     pdb.set_trace()
            prev_output_tokens[i][1:pred_len] = (t[:pred_len]*oracle_or_groundtruth[:pred_len]+best_item['tokens']*(1-oracle_or_groundtruth[:pred_len]))[:-1]
            i+=1
        #self.train()
        return prev_output_tokens # 返回每个位置需要采取的训练方式
    # TorchScript doesn't support optional arguments with variable length (**kwargs).
    # Current workaround is to add union of all arguments in child classes.
    def forward(
            self,
            src_tokens,
            src_lengths,
            prev_output_tokens,
            target=None,
            cls_input: Optional[Tensor] = None,
            return_all_hiddens: bool = True,
            features_only: bool = False,
            alignment_layer: Optional[int] = None,
            alignment_heads: Optional[int] = None,
    ):
        # pdb.set_trace()
        # 获取编码器输出
        encoder_out = self.encoder(src_tokens, src_lengths=src_lengths, cls_input=cls_input,
                                   return_all_hiddens=return_all_hiddens, )
        with torch.no_grad(): 
            if self.training :# 如果是在训练阶段
                # 选取一个阈值用于决定是否进行混合训练，这个阈值可以随着epoch也可以随着训练步数衰减
                prob = self.decay_prob(self.epoch-32,or_type=3,k=self.decay_k)
                # pdb.set_trace()
                # prob = 0
                p = random.random()# 获取一个随机数
                if p > prob :# 如果随机数大于当前概率值 则这句话需要进行混合训练
                    if self.train_adapt_type==2:# 先使用sentence级别的词进行得分计算，然后使用token级别的词进行替换
                        # 通过句子级数据获取打分，得到哪些位置需要进行替换
                        oracle_or_groundtruth = self.get_oracle_or_groundtruth(prev_output_tokens, src_tokens, src_lengths, target)
                        # 获取模型真正的预测值，直接全部获取
                        decoder_out = self.decoder(prev_output_tokens, encoder_out=encoder_out, features_only=features_only,src_lengths=src_lengths, return_all_hiddens=return_all_hiddens, )
                        prev_output_tokens = self.get_prev_tokens(decoder_out[0].detach(),prev_output_tokens,oracle_or_groundtruth)
                    elif self.train_adapt_type==1:# 只使用token级别
                        # 获取模型真正的预测值，直接全部获取
                        decoder_out = self.decoder(prev_output_tokens, encoder_out=encoder_out, features_only=features_only,src_lengths=src_lengths, return_all_hiddens=return_all_hiddens, )
                        prev_output_tokens = self.train_adapt_1_token(decoder_out[0].detach(),prev_output_tokens)
                        #pdb.set_trace()
                        # print('token')
                    elif self.train_adapt_type==0:# 只使用sentence level的输出token 
                        prev_output_tokens = self.train_adapt_0_sentence(prev_output_tokens, src_tokens, src_lengths, target)
                        # print('sentence')
                
            #pdb.set_trace()
        self.train()
        decoder_out = self.decoder(prev_output_tokens, encoder_out=encoder_out, features_only=features_only,src_lengths=src_lengths, return_all_hiddens=return_all_hiddens, )
        # pdb.set_trace()
        return decoder_out

    # Since get_normalized_probs is in the Fairseq Model which is not scriptable,
    # I rewrite the get_normalized_probs from Base Class to call the
    # helper function in the Base Class.
    @torch.jit.export
    def get_normalized_probs(
            self,
            net_output: Tuple[Tensor, Dict[str, List[Optional[Tensor]]]],
            log_probs: bool,
            sample: Optional[Dict[str, Tensor]] = None,
    ):
        """Get normalized probabilities (or log probs) from a net's output."""
        return self.get_normalized_probs_scriptable(net_output, log_probs, sample)


class TransformerEncoder(FairseqEncoder):
    """
    Transformer encoder consisting of *args.encoder_layers* layers. Each layer
    is a :class:`TransformerEncoderLayer`.

    Args:
        args (argparse.Namespace): parsed command-line arguments
        dictionary (~fairseq.data.Dictionary): encoding dictionary
        embed_tokens (torch.nn.Embedding): input embedding
    """

    def __init__(self, args, dictionary, embed_tokens):
        super().__init__(dictionary)
        self.register_buffer("version", torch.Tensor([3]))

        self.dropout = args.dropout
        self.encoder_layerdrop = args.encoder_layerdrop

        embed_dim = embed_tokens.embedding_dim
        self.padding_idx = embed_tokens.padding_idx
        self.max_source_positions = args.max_source_positions

        self.embed_tokens = embed_tokens

        self.embed_scale = 1.0 if args.no_scale_embedding else math.sqrt(embed_dim)

        self.embed_positions = (
            PositionalEmbedding(
                args.max_source_positions,
                embed_dim,
                self.padding_idx,
                learned=args.encoder_learned_pos,
            )
            if not args.no_token_positional_embeddings
            else None
        )

        self.layer_wise_attention = getattr(args, "layer_wise_attention", False)

        self.layers = nn.ModuleList([])
        self.layers.extend(
            [self.build_encoder_layer(args) for i in range(args.encoder_layers)]
        )
        self.num_layers = len(self.layers)

        if args.encoder_normalize_before:
            self.layer_norm = LayerNorm(embed_dim)
        else:
            self.layer_norm = None
        if getattr(args, "layernorm_embedding", False):
            self.layernorm_embedding = LayerNorm(embed_dim)
        else:
            self.layernorm_embedding = None

    def build_encoder_layer(self, args):
        return TransformerEncoderLayer(args)

    def forward_embedding(self, src_tokens):
        # embed tokens and positions
        x = embed = self.embed_scale * self.embed_tokens(src_tokens)
        if self.embed_positions is not None:
            x = embed + self.embed_positions(src_tokens)
        if self.layernorm_embedding is not None:
            x = self.layernorm_embedding(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        return x, embed

    def forward(
            self,
            src_tokens,
            src_lengths,
            cls_input: Optional[Tensor] = None,
            return_all_hiddens: bool = False,
    ):
        if self.layer_wise_attention:
            return_all_hiddens = True

        x, encoder_embedding = self.forward_embedding(src_tokens)

        # B x T x C -> T x B x C
        x = x.transpose(0, 1)

        # compute padding mask
        encoder_padding_mask = src_tokens.eq(self.padding_idx)

        encoder_states = [] if return_all_hiddens else None

        # encoder layers
        for layer in self.layers:
            # add LayerDrop (see https://arxiv.org/abs/1909.11556 for description)
            dropout_probability = torch.empty(1).uniform_()
            if not self.training or (dropout_probability > self.encoder_layerdrop):
                x = layer(x, encoder_padding_mask)
                if return_all_hiddens:
                    assert encoder_states is not None
                    encoder_states.append(x)

        if self.layer_norm is not None:
            x = self.layer_norm(x)
            if return_all_hiddens:
                encoder_states[-1] = x

        return EncoderOut(
            encoder_out=x,  # T x B x C
            encoder_padding_mask=encoder_padding_mask,  # B x T
            encoder_embedding=encoder_embedding,  # B x T x C
            encoder_states=encoder_states,  # List[T x B x C]
        )

    @torch.jit.export
    def reorder_encoder_out(self, encoder_out: EncoderOut, new_order):
        """
        Reorder encoder output according to *new_order*.

        Args:
            encoder_out: output from the ``forward()`` method
            new_order (LongTensor): desired order

        Returns:
            *encoder_out* rearranged according to *new_order*
        """
        new_encoder_out: Dict[str, Tensor] = {}

        new_encoder_out["encoder_out"] = (
            encoder_out.encoder_out
            if encoder_out.encoder_out is None
            else encoder_out.encoder_out.index_select(1, new_order)
        )
        new_encoder_out["encoder_padding_mask"] = (
            encoder_out.encoder_padding_mask
            if encoder_out.encoder_padding_mask is None
            else encoder_out.encoder_padding_mask.index_select(0, new_order)
        )
        new_encoder_out["encoder_embedding"] = (
            encoder_out.encoder_embedding
            if encoder_out.encoder_embedding is None
            else encoder_out.encoder_embedding.index_select(0, new_order)
        )

        encoder_states = encoder_out.encoder_states
        if encoder_states is not None:
            for idx, state in enumerate(encoder_states):
                encoder_states[idx] = state.index_select(1, new_order)

        return EncoderOut(
            encoder_out=new_encoder_out["encoder_out"],  # T x B x C
            encoder_padding_mask=new_encoder_out["encoder_padding_mask"],  # B x T
            encoder_embedding=new_encoder_out["encoder_embedding"],  # B x T x C
            encoder_states=encoder_states,  # List[T x B x C]
        )

    def max_positions(self):
        """Maximum input length supported by the encoder."""
        if self.embed_positions is None:
            return self.max_source_positions
        return min(self.max_source_positions, self.embed_positions.max_positions)

    def buffered_future_mask(self, tensor):
        dim = tensor.size(0)
        if (
                not hasattr(self, "_future_mask")
                or self._future_mask is None
                or self._future_mask.device != tensor.device
        ):
            self._future_mask = torch.triu(
                utils.fill_with_neg_inf(tensor.new(dim, dim)), 1
            )
            if self._future_mask.size(0) < dim:
                self._future_mask = torch.triu(
                    utils.fill_with_neg_inf(self._future_mask.resize_(dim, dim)), 1
                )
        return self._future_mask[:dim, :dim]

    def upgrade_state_dict_named(self, state_dict, name):
        """Upgrade a (possibly old) state dict for new versions of fairseq."""
        if isinstance(self.embed_positions, SinusoidalPositionalEmbedding):
            weights_key = "{}.embed_positions.weights".format(name)
            if weights_key in state_dict:
                print("deleting {0}".format(weights_key))
                del state_dict[weights_key]
            state_dict[
                "{}.embed_positions._float_tensor".format(name)
            ] = torch.FloatTensor(1)
        for i in range(self.num_layers):
            # update layer norms
            self.layers[i].upgrade_state_dict_named(
                state_dict, "{}.layers.{}".format(name, i)
            )

        version_key = "{}.version".format(name)
        if utils.item(state_dict.get(version_key, torch.Tensor([1]))[0]) < 2:
            # earlier checkpoints did not normalize after the stack of layers
            self.layer_norm = None
            self.normalize = False
            state_dict[version_key] = torch.Tensor([1])
        return state_dict


class TransformerDecoder(FairseqIncrementalDecoder):
    """
    Transformer decoder consisting of *args.decoder_layers* layers. Each layer
    is a :class:`TransformerDecoderLayer`.

    Args:
        args (argparse.Namespace): parsed command-line arguments
        dictionary (~fairseq.data.Dictionary): decoding dictionary
        embed_tokens (torch.nn.Embedding): output embedding
        no_encoder_attn (bool, optional): whether to attend to encoder outputs
            (default: False).
    """

    def __init__(self, args, dictionary, embed_tokens, no_encoder_attn=False):
        self.args = args
        super().__init__(dictionary)
        self.register_buffer("version", torch.Tensor([3]))
        self._future_mask = torch.empty(0)

        self.dropout = args.dropout
        self.decoder_layerdrop = args.decoder_layerdrop
        self.share_input_output_embed = args.share_decoder_input_output_embed

        input_embed_dim = embed_tokens.embedding_dim
        embed_dim = args.decoder_embed_dim
        self.embed_dim = embed_dim
        self.output_embed_dim = args.decoder_output_dim

        self.padding_idx = embed_tokens.padding_idx
        self.max_target_positions = args.max_target_positions

        self.embed_tokens = embed_tokens

        self.embed_scale = 1.0 if args.no_scale_embedding else math.sqrt(embed_dim)

        self.project_in_dim = (
            Linear(input_embed_dim, embed_dim, bias=False)
            if embed_dim != input_embed_dim
            else None
        )

        self.embed_positions = (
            PositionalEmbedding(
                args.max_target_positions,
                embed_dim,
                self.padding_idx,
                learned=args.decoder_learned_pos,
            )
            if not args.no_token_positional_embeddings
            else None
        )

        self.cross_self_attention = getattr(args, "cross_self_attention", False)
        self.layer_wise_attention = getattr(args, "layer_wise_attention", False)

        self.layers = nn.ModuleList([])
        self.layers.extend(
            [
                self.build_decoder_layer(args, no_encoder_attn)
                for _ in range(args.decoder_layers)
            ]
        )
        self.num_layers = len(self.layers)

        self.adaptive_softmax = None

        self.project_out_dim = (
            Linear(embed_dim, self.output_embed_dim, bias=False)
            if embed_dim != self.output_embed_dim and not args.tie_adaptive_weights
            else None
        )

        if args.adaptive_softmax_cutoff is not None:
            self.adaptive_softmax = AdaptiveSoftmax(
                len(dictionary),
                self.output_embed_dim,
                options.eval_str_list(args.adaptive_softmax_cutoff, type=int),
                dropout=args.adaptive_softmax_dropout,
                adaptive_inputs=embed_tokens if args.tie_adaptive_weights else None,
                factor=args.adaptive_softmax_factor,
                tie_proj=args.tie_adaptive_proj,
            )
        elif not self.share_input_output_embed:
            self.embed_out = nn.Parameter(
                torch.Tensor(len(dictionary), self.output_embed_dim)
            )
            nn.init.normal_(self.embed_out, mean=0, std=self.output_embed_dim ** -0.5)

        if args.decoder_normalize_before and not getattr(
                args, "no_decoder_final_norm", False
        ):
            self.layer_norm = LayerNorm(embed_dim)
        else:
            self.layer_norm = None
        if getattr(args, "layernorm_embedding", False):
            self.layernorm_embedding = LayerNorm(embed_dim)
        else:
            self.layernorm_embedding = None

    def build_decoder_layer(self, args, no_encoder_attn=False):
        return TransformerDecoderLayer(args, no_encoder_attn)

    def forward(
            self,
            prev_output_tokens,
            encoder_out: Optional[EncoderOut] = None,
            incremental_state: Optional[Dict[str, Dict[str, Optional[Tensor]]]] = None,
            features_only: bool = False,
            alignment_layer: Optional[int] = None,
            alignment_heads: Optional[int] = None,
            src_lengths: Optional[Any] = None,
            return_all_hiddens: bool = False,
    ):
        """
        Args:
            prev_output_tokens (LongTensor): previous decoder outputs of shape
                `(batch, tgt_len)`, for teacher forcing
            encoder_out (optional): output from the encoder, used for
                encoder-side attention
            incremental_state (dict): dictionary used for storing state during
                :ref:`Incremental decoding`
            features_only (bool, optional): only return features without
                applying output layer (default: False).

        Returns:
            tuple:
                - the decoder's output of shape `(batch, tgt_len, vocab)`
                - a dictionary with any model-specific outputs
        """
        x, extra = self.extract_features(
            prev_output_tokens,
            encoder_out=encoder_out,
            incremental_state=incremental_state,
            alignment_layer=alignment_layer,
            alignment_heads=alignment_heads,
        )
        if not features_only:
            x = self.output_layer(x)
        return x, extra

    def extract_features(
            self,
            prev_output_tokens,
            encoder_out: Optional[EncoderOut] = None,
            incremental_state: Optional[Dict[str, Dict[str, Optional[Tensor]]]] = None,
            full_context_alignment: bool = False,
            alignment_layer: Optional[int] = None,
            alignment_heads: Optional[int] = None,
    ):
        """
        Similar to *forward* but only return features.

        Includes several features from "Jointly Learning to Align and
        Translate with Transformer Models" (Garg et al., EMNLP 2019).

        Args:
            full_context_alignment (bool, optional): don't apply
                auto-regressive mask to self-attention (default: False).
            alignment_layer (int, optional): return mean alignment over
                heads at this layer (default: last layer).
            alignment_heads (int, optional): only average alignment over
                this many heads (default: all heads).

        Returns:
            tuple:
                - the decoder's features of shape `(batch, tgt_len, embed_dim)`
                - a dictionary with any model-specific outputs
        """
        if alignment_layer is None:
            alignment_layer = self.num_layers - 1

        # embed positions
        positions = (
            self.embed_positions(
                prev_output_tokens, incremental_state=incremental_state
            )
            if self.embed_positions is not None
            else None
        )

        if incremental_state is not None:
            prev_output_tokens = prev_output_tokens[:, -1:]
            if positions is not None:
                positions = positions[:, -1:]

        # embed tokens and positions
        x = self.embed_scale * self.embed_tokens(prev_output_tokens)

        if self.project_in_dim is not None:
            x = self.project_in_dim(x)

        if positions is not None:
            x += positions

        if self.layernorm_embedding is not None:
            x = self.layernorm_embedding(x)

        x = F.dropout(x, p=self.dropout, training=self.training)

        # B x T x C -> T x B x C
        x = x.transpose(0, 1)

        self_attn_padding_mask: Optional[Tensor] = None
        if self.cross_self_attention or prev_output_tokens.eq(self.padding_idx).any():
            self_attn_padding_mask = prev_output_tokens.eq(self.padding_idx)

        # decoder layers
        attn: Optional[Tensor] = None
        inner_states: List[Optional[Tensor]] = [x]
        for idx, layer in enumerate(self.layers):
            encoder_state: Optional[Tensor] = None
            if encoder_out is not None:
                if self.layer_wise_attention:
                    encoder_states = encoder_out.encoder_states
                    assert encoder_states is not None
                    encoder_state = encoder_states[idx]
                else:
                    encoder_state = encoder_out.encoder_out

            if incremental_state is None and not full_context_alignment:
                self_attn_mask = self.buffered_future_mask(x)
            else:
                self_attn_mask = None

            # add LayerDrop (see https://arxiv.org/abs/1909.11556 for description)
            dropout_probability = torch.empty(1).uniform_()
            if not self.training or (dropout_probability > self.decoder_layerdrop):
                x, layer_attn, _ = layer(
                    x,
                    encoder_state,
                    encoder_out.encoder_padding_mask
                    if encoder_out is not None
                    else None,
                    incremental_state,
                    self_attn_mask=self_attn_mask,
                    self_attn_padding_mask=self_attn_padding_mask,
                    need_attn=bool((idx == alignment_layer)),
                    need_head_weights=bool((idx == alignment_layer)),
                )
                inner_states.append(x)
                if layer_attn is not None and idx == alignment_layer:
                    attn = layer_attn.float().to(x)

        if attn is not None:
            if alignment_heads is not None:
                attn = attn[:alignment_heads]

            # average probabilities over heads
            attn = attn.mean(dim=0)

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        # T x B x C -> B x T x C
        x = x.transpose(0, 1)

        if self.project_out_dim is not None:
            x = self.project_out_dim(x)

        return x, {"attn": [attn], "inner_states": inner_states}

    def output_layer(self, features):
        """Project features to the vocabulary size."""
        if self.adaptive_softmax is None:
            # project back to size of vocabulary
            if self.share_input_output_embed:
                return F.linear(features, self.embed_tokens.weight)
            else:
                return F.linear(features, self.embed_out)
        else:
            return features

    def max_positions(self):
        """Maximum output length supported by the decoder."""
        if self.embed_positions is None:
            return self.max_target_positions
        return min(self.max_target_positions, self.embed_positions.max_positions)

    def buffered_future_mask(self, tensor):
        dim = tensor.size(0)
        # self._future_mask.device != tensor.device is not working in TorchScript. This is a workaround.
        if (
                self._future_mask.size(0) == 0
                or (not self._future_mask.device == tensor.device)
                or self._future_mask.size(0) < dim
        ):
            self._future_mask = torch.triu(
                utils.fill_with_neg_inf(torch.zeros([dim, dim])), 1
            )
        self._future_mask = self._future_mask.to(tensor)
        return self._future_mask[:dim, :dim]

    # Overwirte the method to temporaily soppurt jit scriptable in Transformer
    @torch.jit.export
    def reorder_incremental_state(
            self,
            incremental_state: Dict[str, Dict[str, Optional[Tensor]]],
            new_order: Tensor,
    ):
        """Scriptable reorder incremental state in the transformer."""
        for layer in self.layers:
            layer.reorder_incremental_state(incremental_state, new_order)

    def upgrade_state_dict_named(self, state_dict, name):
        """Upgrade a (possibly old) state dict for new versions of fairseq."""
        if isinstance(self.embed_positions, SinusoidalPositionalEmbedding):
            weights_key = "{}.embed_positions.weights".format(name)
            if weights_key in state_dict:
                del state_dict[weights_key]
            state_dict[
                "{}.embed_positions._float_tensor".format(name)
            ] = torch.FloatTensor(1)

        for i in range(self.num_layers):
            # update layer norms
            layer_norm_map = {
                "0": "self_attn_layer_norm",
                "1": "encoder_attn_layer_norm",
                "2": "final_layer_norm",
            }
            for old, new in layer_norm_map.items():
                for m in ("weight", "bias"):
                    k = "{}.layers.{}.layer_norms.{}.{}".format(name, i, old, m)
                    if k in state_dict:
                        state_dict[
                            "{}.layers.{}.{}.{}".format(name, i, new, m)
                        ] = state_dict[k]
                        del state_dict[k]

        version_key = "{}.version".format(name)
        if utils.item(state_dict.get(version_key, torch.Tensor([1]))[0]) <= 2:
            # earlier checkpoints did not normalize after the stack of layers
            self.layer_norm = None
            self.normalize = False
            state_dict[version_key] = torch.Tensor([1])

        return state_dict


def Embedding(num_embeddings, embedding_dim, padding_idx):
    m = nn.Embedding(num_embeddings, embedding_dim, padding_idx=padding_idx)
    nn.init.normal_(m.weight, mean=0, std=embedding_dim ** -0.5)
    nn.init.constant_(m.weight[padding_idx], 0)
    return m


def Linear(in_features, out_features, bias=True):
    m = nn.Linear(in_features, out_features, bias)
    nn.init.xavier_uniform_(m.weight)
    if bias:
        nn.init.constant_(m.bias, 0.0)
    return m

@register_model_architecture("adapt_transformer", "adapt_transformer")
def base_architecture(args):
    args.encoder_embed_path = getattr(args, "encoder_embed_path", None)
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 6)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", False)
    args.encoder_learned_pos = getattr(args, "encoder_learned_pos", False)
    args.decoder_embed_path = getattr(args, "decoder_embed_path", None)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", False)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.attention_dropout = getattr(args, "attention_dropout", 0.0)
    args.activation_dropout = getattr(args, "activation_dropout", 0.0)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.dropout = getattr(args, "dropout", 0.1)
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.share_all_embeddings = getattr(args, "share_all_embeddings", False)
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.no_cross_attention = getattr(args, "no_cross_attention", False)
    args.cross_self_attention = getattr(args, "cross_self_attention", False)
    args.layer_wise_attention = getattr(args, "layer_wise_attention", False)

    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)

    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)


@register_model_architecture("adapt_transformer", "adapt_transformer_wmt_en_de")
def transformer_wmt_en_de(args):
    base_architecture(args)
