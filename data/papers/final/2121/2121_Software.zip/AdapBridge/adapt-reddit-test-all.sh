export CUDA_VISIBLE_DEVICES=3
path=base_model_reddit_sentence_oracles_decay_20_t4
pre="checkpoint48"
result=$path/$path.result
data_set=examples/translation/reddit-tok-shh
echo "*************************************" >>$result
echo "$path" >>$result
files=$(ls $path)
for filename in $files
do
    if [[ $files != *$filename.result.txt* ]] && [[ $filename == $pre*.pt ]]
    then
    echo $filename >>$result &&
    python generate.py $data_set/data-bin --path $path/$filename  --remove-bpe --log-format json >$path/$filename.result.txt &&
    cat $path/$filename.result.txt | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/generic/multi-bleu.perl $data_set/tmp/test.re >>$result
    fi
done
