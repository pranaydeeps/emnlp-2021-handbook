# from collections import defaultdict
# import pdb
# import math
# from nltk.translate.bleu_score import sentence_bleu
# from nltk.translate.bleu_score import corpus_bleu
# from nltk.translate.bleu_score import SmoothingFunction
# from bert_score import score
# smooth = SmoothingFunction()

# import random
# def get_all_dist(file_path):
#     ref = open(file_path)
#     res_txt = open(file_path+'.hme','w')
#     fline = []
#     for d in ref:
#         fline.append(d)
#     fdic={}
#     all_sys_txt = []
#     all_ref_txt = []
#     filter_txt = []
#     score_sum =0
#     pcount=0
#     for index in range(len(fline)):
#         sen = fline[index]
#         if 'S-'==sen[:2]:
#             s=' '.join(sen.split()[1:])
#             t=' '.join(fline[index+1].split()[1:])
#             h=' '.join(fline[index+2].split()[2:])
#             all_sys_txt.append(h.split())
#             all_ref_txt.append([t.split()])
#             if s not in fdic:
#                 fdic[s]={'ref':[],'res':''}
#                 fdic[s]['ref'].append(t)
#                 fdic[s]['res']=h
#                 filter_txt.append(h.split())
#             else:
#                 fdic[s]['ref'].append(t)
#         if 'P-'==sen[:2]:
#             lk = sen.split()[1:]
#             lk = [float(x)*math.log(2) for x in lk]
#             score_sum+=sum(lk)
#             pcount+=len(lk)
#     count =0
#     max_bleu=[]

#     test_index=[856, 108, 981, 3, 787, 11, 965, 678, 268, 867, 286, 958, 241, 155, 165, 65, 641, 445, 287, 353, 967, 188, 537, 876, 691, 215, 822, 183, 375, 690, 517, 357, 118, 407, 625, 237, 458, 478, 279, 936, 115, 354, 486, 130, 415, 33, 716, 835, 373, 345, 580, 759, 931, 204, 40, 434, 521, 810, 878, 295, 116, 666, 770, 368, 715, 496, 227, 854, 624, 599, 612, 939, 107, 651, 722, 370, 514, 364, 372, 823, 382, 524, 897, 663, 38, 307, 240, 680, 957, 685, 421, 339, 648, 492, 138, 475, 546, 951, 912, 620, 326, 386, 252, 202, 420, 784, 411, 170, 83, 48, 869, 749, 422, 244, 123, 714, 7, 611, 278, 877, 992, 754, 192, 727, 450, 598, 563, 905, 173, 228, 588, 187, 887, 589, 564, 880, 753, 77, 163, 983, 750, 491, 929, 6, 697, 845, 157, 51, 321, 848, 724, 658, 771, 473, 645, 793, 464, 167, 15, 947, 692, 825, 419, 600, 154, 457, 767, 790, 317, 257, 140, 362, 27, 342, 729, 986, 717, 285, 261, 62, 343, 325, 448, 700, 709, 359, 469, 361, 23, 732, 428, 996, 562, 551, 444, 82, 379, 593, 938, 509, 543, 87, 376, 10, 49, 471, 866, 56, 412, 890, 91, 55, 608, 842, 334, 802, 523, 441, 758, 9, 219, 942, 994, 112, 42, 661, 846, 109, 896, 153, 993, 519, 567, 774, 613, 205, 12, 726, 603, 126, 246, 14, 119, 615, 90, 659, 909, 915, 988, 966, 210, 1, 805, 318, 127, 29]
#     while len(test_index)!=300:
#         d = random.randint(0,len(fdic.keys()))
#         if d not in test_index:
#             test_index.append(d)
#     # pdb.set_trace()
#     idx = open('questions.txt','w')
#     qus_l = []
#     # for q in qus_f:
#     context = [c for c in fdic.keys()]
#     count=0
#     hscore = []
#     scount = [0,0,0]
#     # for id in test_index:
#     for id in test_index:
#         # print(len(test_index))
#         print(id)
#         idx.write(context[id]+'\n')
#     idx.close()

# file_path = 'adapt_dia_model_1_token_col_de10_dump/checkpoint1.pt.result.txt'
# get_all_dist(file_path)


# # 用于计算输出的distinct得分
# def calc_diversity(txt):
#     tokens = [0.0,0.0,0]
#     types = [defaultdict(int),defaultdict(int),defaultdict(int)]
#     for words in txt:
#         for n in range(3):
#             for idx in range(len(words)-n):
#                 ngram = ' '.join(words[idx:idx+n+1])# 获取n+1gram的词
#                 types[n][ngram] = 1 # 将n+1gram存入词典中
#                 tokens[n] += 1 # 获取总的词语个数
#     div1 = len(types[0].keys())/tokens[0] # 所有n+1gram的种类个数 除以所有词的个数
#     div2 = len(types[1].keys())/tokens[1]
#     return [div1, div2],'DIS-1 = {:.4f} \t DIS-2 = {:.4f}'.format(div1,div2)

# def get_max_bleu(ref,sys):# 计算BLEU值
#     rs = [sentence_bleu([r],sys,weights=(0.5, 0.5),smoothing_function=smooth.method1)for r in ref]
#     return max(rs)

# def get_max_bert_score(ref,sys):# 计算bertscoreF1 得分
#             pdb.set_trace()
#             P, R, F1 = score([sys]*len(ref), ref, lang="zh", verbose=True)
#             return max(F1.tolist())
#             pdb.set_trace()
import random
def get_all_dist(file_path):
    ref = open(file_path,encoding='utf-8')
    res_txt = open(file_path+'.hme','w',encoding='utf-8')
    fline = []
    for d in ref:
        fline.append(d)
    fdic={}
    all_sys_txt = []
    all_ref_txt = []
    filter_txt = []
    score_sum =0
    pcount=0
    for index in range(len(fline)):
        sen = fline[index]
        if 'S-'==sen[:2]:
            s=' '.join(sen.split()[1:])
            t=' '.join(fline[index+1].split()[1:])
            h=' '.join(fline[index+2].split()[2:])
            all_sys_txt.append(h.split())
            all_ref_txt.append([t.split()])
            if s not in fdic:
                fdic[s]={'ref':[],'res':''}
                fdic[s]['ref'].append(t)
                fdic[s]['res']=h
                filter_txt.append(h.split())
            else:
                fdic[s]['ref'].append(t)
    count =0
    max_bleu=[]

    qus_f = open('questions.txt',encoding='utf-8')
    count=0
    hscore = []
    scount = [0,0,0]

    # f = open('outputs.txt')
    # st = ''
    # for l in f:
    #     st+=l
    # score = []
    # st = st.split('\n')
    # for i in range(7,len(st)+1,10):
    #     score.append(st[i])

    for qu in qus_f:
        # print(qu)
        qu=qu[:-1]
        print('*'*50+'\n')
        count+=1
        # pdb.set_trace()
        print(count,'/300\n')
        print('对话输入：'+qu+'\n')
        res_txt.write('对话输入：'+qu+'\n')
        print('模型输出：'+fdic[qu]['res']+'\n')
        res_txt.write('模型输出：'+fdic[qu]['res']+'\n')
        # print('真实输出：'+fdic[qu]['ref'][0]+'\n')
        # res_txt.write('真实输出：'+fdic[qu]['ref'][0]+'\n')
        sc = 3
        # hscore.append(random.randint(1,3))
        while True:
            print('请给出打分：3，2，1 (相关，一般，不相关)')
            # if count<247:
            #     sc = score[count-1]
            # else:
            sc = input()
            if sc in ['1','2','3']:
                res_txt.write('score: '+sc+'\n\n')
                hscore.append(int(sc))
                scount[int(sc)-1]+=1
                print(scount)
                break
    # for k in hscore:
    #     scount[k-1]+=1
    m_score = sum(hscore)/len(hscore)
    rs= '\n得分1个数: '+str(scount[0])+'/'+str(len(hscore))+'  '+str(scount[0]/len(hscore))
    rs+= '\n得分2个数: '+str(scount[1])+'/'+str(len(hscore))+'  '+str(scount[1]/len(hscore))
    rs+= '\n得分3个数: '+str(scount[2])+'/'+str(len(hscore))+'  '+str(scount[2]/len(hscore))
    rs+= '\nMean Score: '+str(m_score)
    res_txt.write(rs)
    print(rs)    
      

file_path = 'base_model_stc_word_oracles_decay_10_t4/checkpoint61.pt.result.txt'
get_all_dist(file_path)

# import pdb
# f = open('outputs.txt')
# st = ''
# for l in f:
#     st+=l
# score = []
# st = st.split('\n')
# for i in range(7,len(st)+1,10):
#     score.append(st[i])
# pdb.set_trace()
