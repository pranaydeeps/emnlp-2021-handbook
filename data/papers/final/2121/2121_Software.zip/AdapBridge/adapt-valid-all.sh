path=adapt_model_1_token_col_de20
pre="checkpoint63"
result=$path/$path.result_val
echo "*************************************" >>$result
echo "$path" >>$result
files=$(ls $path)
for filename in $files
do
    if [[ $files != *$filename.result.val* ]] && [[ $filename == $pre*.pt ]]
    then
    echo $filename >>$result &&
    echo "valid" >>$result &&
    fairseq-generate examples/translation/wmt14_en_de/data-bin --gen-subset valid --batch-size 128 --path $path/$filename  --remove-bpe --sacrebleu >$path/$filename.result.val &&
    cat $path/$filename.result.val | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/generic/multi-bleu.perl examples/translation/wmt14_en_de/tmp/valid.de >>$result  
    # cat $path/$filename.result.val  | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/tokenizer/detokenizer.perl | sacrebleu --valid-set wmt14/full -l en-de >>$result    
    fi
done
