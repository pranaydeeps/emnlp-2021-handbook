export CUDA_VISIBLE_DEVICES=3
path=checkpoints
data_dir=examples/translation/stc-tok
pre="checkpoint"
result=$path/$path.result
echo "*************************************" >>$result
echo "$path" >>$result
files=$(ls $path)
for filename in $files
do
    if [[ $files != *$filename.result.txt* ]] && [[ $filename == $pre*.pt ]]
    then
    echo $filename >>$result &&
    python generate.py $data_dir/data-bin --path $path/$filename  --remove-bpe --log-format json >$path/$filename.result.txt
    # cat $path/$filename.result.txt | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/generic/multi-bleu.perl $data_dir/tmp/test.re >>$result
    fi
done
