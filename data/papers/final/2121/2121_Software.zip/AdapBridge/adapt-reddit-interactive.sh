model_dir=adapt_reddit_model_1_de10_rm
model=checkpoint5
data_dir=examples/translation/reddit-tok-rm
fairseq-interactive \
    --path $model_dir/$model.pt $data_dir/data-bin \
    --beam 5 --source-lang qu --target-lang re \
    --tokenizer moses \
    --bpe subword_nmt --bpe-codes $data_dir/code
