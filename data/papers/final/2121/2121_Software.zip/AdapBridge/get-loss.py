fpath = 'adapt_model_1_token_col/training.log'
f = open(fpath)
# f = open('train-'+fpath+'.out')
loss = []
for l in f:
    # if '| train | ' in l:
    #     l=l.split('|')
    #     lo = l[3].split()[4:6]
    #     print(lo)
    #     loss.append(float(l[3].split()[5][1:-2]))

    if '| train | epoch' in l:
        l=l.split('|')
        lo = l[4]
        print(l[3]+lo)
        loss.append(float(lo.split()[-1]))
print(loss)