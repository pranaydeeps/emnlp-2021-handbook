model_dir=adapt_dia_model_1_token_col_de10_dump
model=checkpoint51
data_dir=examples/translation/stc-tok
fairseq-interactive \
    --path $model_dir/$model.pt $data_dir/data-bin \
    --beam 5 --source-lang qu --target-lang re \
    --tokenizer moses \
    --bpe subword_nmt --bpe-codes $data_dir/code
