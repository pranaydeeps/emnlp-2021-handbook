model_dir=adapt_model_small_1_token/checkpoint16.pt
outfile=adapt_model_small_1_token
fairseq-generate examples/translation/wmt14_en_de_small/data-bin --path $model_dir --remove-bpe --sacrebleu > $outfile.txt &&
cat $outfile.txt | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/tokenizer/detokenizer.perl | sacrebleu -t wmt14/full -l en-de
