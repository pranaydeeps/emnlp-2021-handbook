export CUDA_VISIBLE_DEVICES=0
path=checkpoints
pre="checkpoint"
result=$path/$path.result.val
data_set=examples/translation/stc-tok
echo "*************************************" >>$result
echo "$path" >>$result
files=$(ls $path)
for filename in $files
do
    if [[ $files != *$filename.result.val* ]] && [[ $filename == $pre*.pt ]]
    then
    echo $filename >>$result &&
    echo "valid" >>$result &&
    python generate.py $data_set/data-bin --gen-subset valid --batch-size 128 --path $path/$filename  --remove-bpe --sacrebleu >$path/$filename.result.val
    # cat $path/$filename.result.val | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/generic/multi-bleu.perl $data_set/valid.re >>$result  
    # cat $path/$filename.result.val  | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/tokenizer/detokenizer.perl | sacrebleu --valid-set wmt14/full -l en-de >>$result    
    fi
done
