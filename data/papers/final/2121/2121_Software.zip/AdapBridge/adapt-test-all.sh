path=base_model_stc_sentence_oracles_decay_10_t4
pre="checkpoint_best"
result=$path/$path.result
echo "*************************************" >>$result
echo "$path" >>$result
files=$(ls $path)
for filename in $files
do
    if [[ $files != *$filename.result.txt* ]] && [[ $filename == $pre*.pt ]]
    then
    echo $filename >>$result &&
    fairseq-generate examples/translation/wmt14_en_de/data-bin --path $path/$filename  --remove-bpe --sacrebleu >$path/$filename.result.txt &&
    cat $path/$filename.result.txt | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/generic/multi-bleu.perl examples/translation/wmt14_en_de/tmp/test.de >>$result &&  
    cat $path/$filename.result.txt  | grep ^H | sort -nr -k1.2 | cut -f3- | ./examples/translation/mosesdecoder/scripts/tokenizer/detokenizer.perl | sacrebleu -t wmt14/full -l en-de >>$result    
    fi
done
