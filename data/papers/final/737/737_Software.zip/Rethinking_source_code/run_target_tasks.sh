bash train_rte.sh
bash train_mednli.sh
bash train_wic.sh
bash train_cola.sh
bash train_iqa.sh
bash train_wino_xs.sh
bash train_wino_m.sh
