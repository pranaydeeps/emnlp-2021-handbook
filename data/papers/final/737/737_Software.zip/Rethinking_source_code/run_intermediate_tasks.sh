bash train_hella.sh
bash train_hella-p.sh
bash train_synth.sh
