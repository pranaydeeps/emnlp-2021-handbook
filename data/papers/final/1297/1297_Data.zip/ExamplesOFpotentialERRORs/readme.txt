The argument in each line is signaled with the apostrophes (located at the front and back of the argument).
"wsj" denotes the field of document ID.
"tensor" denotes the similarity score that is calculated using CLS embeddings.
The label of relation type is given behind the argument pair.
Every example is consisted with two pairs of arguments which are of similar semantics but hold different relations.
The solid line is used to separate different examples.
