# Cleaned OS Dialogs Dataset (4M)

The dataset can be downloaded from: [https://drive.google.com/file/d/1nJy2oUbEUPVf83LDJc5Yd5D-rLtTtA-s/view?usp=sharing](https://drive.google.com/file/d/1nJy2oUbEUPVf83LDJc5Yd5D-rLtTtA-s/view?usp=sharing)

### Bibliography

Lison, P.; Tiedemann, J.; Kouylekov, M.; et al. 2019.  Opensubtitles 2018: Statistical rescoring of sentence alignments inlarge, noisy parallel corpora.  In *LREC 2018, Eleventh Inter-national Conference on Language Resources and Evaluation*. European Language Resources Association (ELRA).