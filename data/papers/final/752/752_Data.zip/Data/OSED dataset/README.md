# OSED (Open-Subtitles Emotional Dialogues) Dataset (1M)

The dataset can be downloaded from: [https://drive.google.com/file/d/1KEXAcHpnjyZ1Gedg5Jxs6x_uOSqjYjTd/view?usp=sharing](https://drive.google.com/file/d/1KEXAcHpnjyZ1Gedg5Jxs6x_uOSqjYjTd/view?usp=sharing)