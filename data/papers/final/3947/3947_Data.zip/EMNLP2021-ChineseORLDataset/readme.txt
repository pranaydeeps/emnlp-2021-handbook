
Manual annotation Chinese ORL dataset:
gold-standard-ChineseORL/acl21orl.ch.train.txt
gold-standard-ChineseORL/acl21orl.ch.dev.txt
gold-standard-ChineseORL/acl21orl.ch.test.txt

Full auto translate and annotate from the train dataset of MPQA:
auto/acl21orl.ch.train.en.auto.txt

Manual translate and auto annotate from the train dataset of MPQA:
auto/acl21orl.train.en.half-auto.txt

Full auto translate and annotate from the all dataset of Portuguese:
auto/acl21orl.ch.train.pt.auto.txt

train dataset in MPQA:
public-data/train.en.conll


full dataset in Portuguese:
public-data/pt.conll


Notice that the symbol * in DSE-* tag is not indicate the head of DSE span, it doesn't mean anything here.
