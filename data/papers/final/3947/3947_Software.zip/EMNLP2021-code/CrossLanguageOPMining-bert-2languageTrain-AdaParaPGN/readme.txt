This code is for bilingual training.
run this code just only do it:
sh runme.sh