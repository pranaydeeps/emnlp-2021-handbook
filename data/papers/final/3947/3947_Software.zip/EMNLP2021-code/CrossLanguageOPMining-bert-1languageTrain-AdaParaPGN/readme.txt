This code is for monolingual training.
run this code just only do it:
sh runme.sh