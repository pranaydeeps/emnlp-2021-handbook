This code is for multilingual training.
run this code just only do it:
sh runme.sh