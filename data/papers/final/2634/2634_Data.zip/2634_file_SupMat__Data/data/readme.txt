Since all data is too big and exceeds file limit,
for the review data, please download from: http://jmcauley.ucsd.edu/data/amazon/; 
Quora question pairs data is from https://www.kaggle.com/c/quora-question-pairs; 
AnalytiCup dataset is from http://www.tianchi.aliyun.com/competition/introduction.htmraceId=231661