### Experiments on WinoLogic: Using Pre-trained Objectives(Baseline 1) and Sequence Classification(Baseline 3)

The introduction is shown in the 'pretrained-objectives.ipynb' 

### Experiments on WinoLogic: Using Auxiliary Classifier(Baseline 2)

To reimplement the experiment results, user should assign the path values to ROOT_PATH, WINOWHY_PATH, WINOLOGIC_PATH and CACHE_DIR in both files 'auxilliary-classifier.py' and 'auxilliary-classifier-batch.py'.

To reimplement the results of large models ( 'bert-large-uncased', 'roberta-large', 'gpt2-large') and GPT-2 small model ('gpt2'), user can modify the values of model_name, seed, learning_rate and num_training_epochs in the file 'auxilliary-classifier.py' and run command 'python auxilliary-classifier.py'

To reimplement the results of small models ( 'bert-base-uncased', 'roberta-base'), user can modify the values of model_name, seed, batch_size, learning_rate and num_training_epochs in the file 'auxilliary-classifier-batch.py' and run command 'python auxilliary-classifier-batch.py'
