# Argument Reasoning Comprehension Task (ARCT)

This folder contains the revised dataset [(Niven and Kao, 2019)](https://aclanthology.org/P19-1459/) for the Argument Reasoning Comprehension Task [(Habernal et al., 2018)](https://aclanthology.org/N18-1175/).
