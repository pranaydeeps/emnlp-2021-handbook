# Physical Interaction: Question Answering (PIQA)

This folder contains the data for the Physical Interaction: Question Answering task [(Bisk et al., 2020)](https://arxiv.org/abs/1911.11641).
