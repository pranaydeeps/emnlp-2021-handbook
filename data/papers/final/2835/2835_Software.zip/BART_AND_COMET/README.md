# BART & COMET(BART)

This folder contains the code to run the experiments with BART and COMET(BART).

The pre-training weights for COMET(BART) were obtained from the original distribution by its authors, which you can [download here](https://github.com/allenai/comet-atomic-2020/#model-comet-atomic-2020).
