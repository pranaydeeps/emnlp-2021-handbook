"""

Multi TranslationDataset
=============================
"""

from .ted_multi import TedMultiTranslationDataset
