textattack.datasets.translation package
=======================================

.. automodule:: textattack.datasets.translation
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.datasets.translation.ted_multi
   :members:
   :undoc-members:
   :show-inheritance:
