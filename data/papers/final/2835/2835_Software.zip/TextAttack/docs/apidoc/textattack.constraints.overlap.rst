textattack.constraints.overlap package
======================================

.. automodule:: textattack.constraints.overlap
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.constraints.overlap.bleu_score
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.constraints.overlap.chrf_score
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.constraints.overlap.levenshtein_edit_distance
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.constraints.overlap.max_words_perturbed
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.constraints.overlap.meteor_score
   :members:
   :undoc-members:
   :show-inheritance:
