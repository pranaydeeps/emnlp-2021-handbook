textattack.goal\_functions.text package
=======================================

.. automodule:: textattack.goal_functions.text
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.goal_functions.text.minimize_bleu
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_functions.text.non_overlapping_output
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_functions.text.text_to_text_goal_function
   :members:
   :undoc-members:
   :show-inheritance:
