textattack.datasets package
===========================

.. automodule:: textattack.datasets
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 6

   textattack.datasets.translation



.. automodule:: textattack.datasets.dataset
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.datasets.huggingface_dataset
   :members:
   :undoc-members:
   :show-inheritance:
