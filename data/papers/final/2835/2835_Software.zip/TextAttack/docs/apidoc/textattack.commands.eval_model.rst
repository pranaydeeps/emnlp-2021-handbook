textattack.commands.eval\_model package
=======================================

.. automodule:: textattack.commands.eval_model
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.commands.eval_model.eval_model_command
   :members:
   :undoc-members:
   :show-inheritance:
