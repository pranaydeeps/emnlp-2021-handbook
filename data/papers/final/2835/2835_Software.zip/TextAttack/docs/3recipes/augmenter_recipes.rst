======================
Augmenter Recipes
======================

Transformations and constraints can be used for simple NLP data augmentations. Here is a list of recipes for NLP data augmentations

.. automodule:: textattack.augmentation.recipes
   :members:
   :noindex:
