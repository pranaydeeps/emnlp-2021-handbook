# NS-KPE


This code is based on [BERT-KPE](https://github.com/thunlp/BERT-KPE), we introduce negative sampling to adjust training loss to mitigate the misguidance brought by unlabeled keyphrases.