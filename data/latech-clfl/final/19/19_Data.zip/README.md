# FairyNet-LaTeCH-CLfL

Repository for the LaTeCH-CLfL 2021 paper **The FairyNet Corpus - Character Networks for German Fairy Tales**

## About the FairyNet corpus
FairyNet is a corpus of coreference-annotated files and character networks for 40 fairy tales from the seventh edition of the [Kinder- und Hausmärchen](https://de.wikisource.org/wiki/Kinder-_und_Hausm%C3%A4rchen) from the Brothers Grimm (we plan to annotate the remaining fairy tales in the future). For each fairy tale, there are two files: an xmi-file containing the text and hand-annotated mentions with coreference ids indicating the clusters and an xlsx-file containing the important characters of the fairy tale and their relations. 

## The folders in the repository
The repository contains the following folders:
- **interannotatoragreement**: contains folders for the files which the annotators created before they compared and unified their versions
- **networks**: contains the final networks as xlsx-files
- **networks-json**: contains the final networks as json-files
- **text**: contains the text (without annotations) of the 40 fairy tales (downloaded from [Wikisource](https://de.wikisource.org/wiki/Kinder-_und_Hausm%C3%A4rchen) and modernized with a [tool from Deutsches Textarchiv](https://www.deutschestextarchiv.de/demo/cab)
- **uima-typesystem**: contains the TypeSystem required to load the xmi-files
- **xmi-c2f**: contains the annotated results of the c2f algorithm
- **xmi-gold**: contains the files with hand-annotated coreference information
- **xmi-rules**: contains the annotated results of the rule-based algorithm

## Viewing XMI files
The xmi-files use the [Apache UIMA](https://uima.apache.org/) XMI format and can be viewed with our web editor [webAthen](https://webathen-beta.informatik.uni-wuerzburg.de/) (simply drag & drop a file onto the large text area).