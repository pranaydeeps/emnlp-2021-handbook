## Important Information to replicate our results

- The Key_Points.csv file that was generated in notebook 2, was then downloaded and then the key_point_id were given manually, in continuation with the sequence of the test dataset key_points.csv. For example, if key_points for topic 1 ends on serial number kp_0_8, then the generated key_points's key_point id for topic 1 starts from the id kp_0_9 and so on for the rest of the two topics (out of the three topics for which we had to generate key_points)
- In some of the cases such as for topic 1 and 3 the number of key_points were generated more than the required, to reduce them the last few key_points were deleted since they were saved in the descending order of their rouge1 - precision scores.
- Model file used in notebook 3 - https://drive.google.com/file/d/1-VCFoCve9grFi_P-RHZy189hO3Pa9UUf/view?usp=sharing

