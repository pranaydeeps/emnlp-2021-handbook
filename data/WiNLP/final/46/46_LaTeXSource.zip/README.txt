* Contents

Makefile	Makefile for compling coling 2018.tex in pdflatex
README.txt	This file
acl.bst		BibTeX `acl' style file
coling2018.dot	Microsoft Word template file for Coling 2018
coling2018.sty	LaTeX style file for Coling 2018
winlp2019.tex	LaTeX sample file for WiNLP 2019
