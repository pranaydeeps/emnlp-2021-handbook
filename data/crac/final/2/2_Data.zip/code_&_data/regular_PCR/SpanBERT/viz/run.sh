#!/bin/bash

python -m http.server 6006
