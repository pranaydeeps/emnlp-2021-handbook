"""
Based on Hugginface example of Causal Language Modeling ( https://github.com/huggingface/transformers/tree/v4.2.2/examples)
Modified to accommodate the use of CoreLM
Used primarly because of the support for DeepSpeed in the HF trainer. 
"""
import logging
import math
import os
import sys
import pickle
from dataclasses import dataclass, field
from typing import Optional
import torch
from torch import optim

from datasets import load_dataset, Features, Value, Dataset
from transformers import GPT2Config, GPT2Tokenizer, GPT2LMHeadModel
from core.modeling_gpt2 import GPT2ELMHeadModel
from core.configuration_gpt2 import GPT2EConfig
from utils.radam import RAdam
from utils.adafactor import AdaFactor
from utils.operations import freeze

import transformers
from transformers import (
    CONFIG_MAPPING,
    MODEL_FOR_CAUSAL_LM_MAPPING,
    AutoConfig,
    AutoModelForCausalLM,
    AutoTokenizer,
    HfArgumentParser,
    Trainer,
    TrainingArguments,
    default_data_collator,
    set_seed,
)
from transformers.trainer_utils import is_main_process


logger = logging.getLogger(__name__)


MODEL_CONFIG_CLASSES = list(MODEL_FOR_CAUSAL_LM_MAPPING.keys())
MODEL_TYPES = tuple(conf.model_type for conf in MODEL_CONFIG_CLASSES)


@dataclass
class ModelArguments:
    """
    Arguments pertaining to which model/config/tokenizer we are going to fine-tune, or train from scratch.
    """

    model_name_or_path: Optional[str] = field(
        default=None,
        metadata={
            "help": "The model checkpoint for weights initialization."
            "Don't set if you want to train a model from scratch."
        },
    )
    model_type: Optional[str] = field(
        default=None,
        metadata={"help": "If training from scratch, pass a model type from the list: " + ", ".join(MODEL_TYPES)},
    )
    config_name: Optional[str] = field(
        default=None, metadata={"help": "Pretrained config name or path if not the same as model_name"}
    )
    tokenizer_name: Optional[str] = field(
        default=None, metadata={"help": "Pretrained tokenizer name or path if not the same as model_name"}
    )
    cache_dir: Optional[str] = field(
        default=None,
        metadata={"help": "Where do you want to store the pretrained models downloaded from huggingface.co"},
    )
    use_fast_tokenizer: bool = field(
        default=True,
        metadata={"help": "Whether to use one of the fast tokenizer (backed by the tokenizers library) or not."},
    )
    model_revision: str = field(
        default="main",
        metadata={"help": "The specific model version to use (can be a branch name, tag name or commit id)."},
    )
    use_auth_token: bool = field(
        default=False,
        metadata={
            "help": "Will use the token generated when running `transformers-cli login` (necessary to use this script "
            "with private models)."
        },
    )
    optimizer: Optional[str] = field(
        default=None,
        metadata={"help": "Options: adam, adamw, radam, adadelta (case sensitive)"},
    )
    scheduler: Optional[str] = field(
        default=None, metadata={"help": "Options: None (Default), CosineAnnealingLR"}
    )
    tmax: Optional[str] = field(
        default=2000, metadata={"help": "tmax steps for step in "}
    )
    lr_warmup: Optional[str] = field(
        default=2000, metadata={"help": "optimizer warmup before decay"}
    )
    loss: Optional[str] = field(
        default=None,
        metadata={"help": "Options: CrossEntropy, NLLLoss"}
    )
    freeze: bool = field(
        default=False,
        metadata={"help": "Will freeze the model based on the configuration provided in the GPT2EConfig file - or "
                          "initialized by the class if no such file is provided."},
    )


@dataclass
class DataTrainingArguments:
    """
    Arguments pertaining to what data we are going to input our model for training and eval.
    """

    dataset_name: Optional[str] = field(
        default=None, metadata={"help": "The name of the dataset to use (via the datasets library)."}
    )
    dataset_config_name: Optional[str] = field(
        default=None, metadata={"help": "The configuration name of the dataset to use (via the datasets library)."}
    )
    train_file: Optional[str] = field(default=None, metadata={"help": "The input training data file (a text file)."})
    validation_file: Optional[str] = field(
        default=None,
        metadata={"help": "An optional input evaluation data file to evaluate the perplexity on (a text file)."},
    )
    block_size: Optional[int] = field(
        default=None,
        metadata={
            "help": "Optional input sequence length after tokenization."
            "The training dataset will be truncated in block of this size for training."
            "Default to the model max input length for single sentence inputs (take into account special tokens)."
        },
    )
    overwrite_cache: bool = field(
        default=False, metadata={"help": "Overwrite the cached training and evaluation sets"}
    )
    validation_split_percentage: Optional[int] = field(
        default=5,
        metadata={
            "help": "The percentage of the train set used as validation set in case there's no validation split"
        },
    )
    preprocessing_num_workers: Optional[int] = field(
        default=None,
        metadata={"help": "The number of processes to use for the preprocessing."},
    )

    def __post_init__(self):
        if self.dataset_name is None and self.train_file is None and self.validation_file is None:
            raise ValueError("Need either a dataset name or a training/validation file.")
        else:
            if self.train_file is not None:
                extension = self.train_file.split(".")[-1]
                assert extension in ["csv", "json", "txt"], "`train_file` should be a csv, a json or a txt file."
            if self.validation_file is not None:
                extension = self.validation_file.split(".")[-1]
                assert extension in ["csv", "json", "txt"], "`validation_file` should be a csv, a json or a txt file."

@dataclass
class HyperparamArguments:
    """
      Arguments pertaining to which optimizer/scheduler/loss to use.
    """
    optimizer: Optional[str] = field(
        default=None,
        metadata={"help": "Options: Adam, AdamW, Radam, AdaDelta (case sensitive)"},
    )
    scheduler: Optional[str] = field(
        default=None, metadata={"help": "Options: None (Default), CosineAnnealingLR"}
    )
    loss: Optional[str] = field(
        default=None,
        metadata={"help": "Options: CrossEntropy, NLLLoss"}
    )



def main():
    

    parser = HfArgumentParser((ModelArguments, DataTrainingArguments, TrainingArguments))
    if len(sys.argv) == 2 and sys.argv[1].endswith(".json"):
        # If we pass only one argument to the script and it's the path to a json file,
        # let's parse it to get our arguments.
        model_args, data_args, training_args = parser.parse_json_file(json_file=os.path.abspath(sys.argv[1]))
    else:
        model_args, data_args, training_args = parser.parse_args_into_dataclasses()

    if (
        os.path.exists(training_args.output_dir)
        and os.listdir(training_args.output_dir)
        and training_args.do_train
        and not training_args.overwrite_output_dir
    ):
        raise ValueError(
            f"Output directory ({training_args.output_dir}) already exists and is not empty."
            "Use --overwrite_output_dir to overcome."
        )

    # Setup logging
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO if is_main_process(training_args.local_rank) else logging.WARN,
    )

    # Log on each process the small summary:
    logger.warning(
        f"Process rank: {training_args.local_rank}, device: {training_args.device}, n_gpu: {training_args.n_gpu}"
        + f"distributed training: {bool(training_args.local_rank != -1)}, 16-bits training: {training_args.fp16}"
    )
    # Set the verbosity to info of the Transformers logger (on main process only):
    if is_main_process(training_args.local_rank):
        transformers.utils.logging.set_verbosity_info()
        transformers.utils.logging.enable_default_handler()
        transformers.utils.logging.enable_explicit_format()
    logger.info("Training/evaluation parameters %s", training_args)

    # Set seed before initializing model.
    set_seed(training_args.seed)

    if data_args.dataset_name == 'amalgum':
        amalgum_train = 'data/amalgum/train.pkl'
        amalgum_eval = 'data/amalgum/validation.pkl'
        with open(amalgum_train, 'rb') as f:
            ag_train = pickle.load(f)
        with open(amalgum_eval, 'rb') as f:
            ag_eval = pickle.load(f)
        data_ag_t = Dataset.from_dict(ag_train)
        data_ag_v = Dataset.from_dict(ag_eval)
    else:
        print(f"Unrecognized datasets {data_args.dataset_name}\n"
              f"Exiting...")
        return False
        
    config_kwargs = {
        "cache_dir": model_args.cache_dir,
        "revision": model_args.model_revision,
        "use_auth_token": True if model_args.use_auth_token else None,
    }

    if model_args.config_name:
        if model_args.config_name == 'gpt2':
            config = GPT2EConfig.from_pretrained(model_args.config_name)
        else:
            config = GPT2EConfig.from_json_file(model_args.config_name)
        logger.info(f"Initiliazed config from {model_args.config_name}")
    elif model_args.model_name_or_path:

        try:
            config = GPT2EConfig.from_json_file(os.path.join(model_args.model_name_or_path, 'config.json')) #for pretrained
            logger.info(f"Initiliazed config from {os.path.join(model_args.model_name_or_path, 'config.json')}")
        except FileNotFoundError:
            config = GPT2EConfig.from_pretrained(model_args.model_name_or_path)  # for GPT2
            logger.info(f"Initiliazed config from {model_args.config_name} online")


    else:
        config = GPT2Config()
        logger.warning("You are instantiating a new config instance from scratch.")

    print(config)

    tokenizer_kwargs = {
        "cache_dir": model_args.cache_dir,
        "use_fast": model_args.use_fast_tokenizer,
        "revision": model_args.model_revision,
        "use_auth_token": True if model_args.use_auth_token else None,
    }

    if model_args.tokenizer_name:
        tokenizer = GPT2Tokenizer.from_pretrained(model_args.tokenizer_name, **tokenizer_kwargs)
        logger.info(f"Initiliazed tokenizer from {model_args.config_name}")
    elif model_args.model_name_or_path:
        tokenizer = GPT2Tokenizer.from_pretrained(model_args.model_name_or_path, **tokenizer_kwargs)
        logger.info(f"Initiliazed tokenizer from {model_args.model_name_or_path}")
    else:
        raise ValueError(
            "You are instantiating a new tokenizer from scratch. This is not supported by this script."
            "You can do it from another script, save it, and load it from here, using --tokenizer_name."
        )

    if model_args.model_name_or_path:
        # if model_args.model_name_or_path == 'gpt2':
        #     model = GPT2LMHeadModel.from_pretrained(model_args.model_name_or_path)
        model = GPT2ELMHeadModel.from_pretrained(model_args.model_name_or_path)
    else:
        logger.info("Training new model from scratch")
        model = GPT2ELMHeadModel.from_config(config)

    #debug /  model layer configuration with model output
    print(model.transformer.h)

    model.resize_token_embeddings(len(tokenizer))

    # custom optimizer
    if model_args.optimizer:
        logger.info(f"Optimizer set to: {model_args.optimizer}")
        if model_args.optimizer == 'adam':
            # optimizer = optim.Adam(model.parameters(), lr=training_args.learning_rate)
            optimizer = torch.optim.Adam(model.parameters(), lr=training_args.learning_rate, amsgrad=True)
        if model_args.optimizer == 'adamw':
            optimizer = optim.AdamW(model.parameters(), lr=training_args.learning_rate)
        if model_args.optimizer == 'radam':
            optimizer = RAdam(model.parameters(), lr=training_args.learning_rate)
        if model_args.optimizer == 'adadelta':
            optimizer = optim.AdamDelta(model.parameters(), lr=training_args.learning_rate)
        if model_args.optimizer == 'adafactor':
            optimizer = transformers.Adafactor(model.parameters(),  lr=training_args.learning_rate,
                                               relative_step=False, warmup_init=False)
    else:
        optimizer = optim.Adam(model.parameters(), lr=training_args.learning_rate)

    if model_args.scheduler:
        if model_args.scheduler == 'lambda':
            lr_scheduler = optim.lr_scheduler.LambdaLR(optimizer)
        if model_args.scheduler == 'cosine':
            lr_scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=model_args.t_max)
        if model_args.scheduler == 'default':
            lr_scheduler = transformers.get_linear_schedule_with_warmup(optimizer, model_args.lr_warmup,
                                                                        training_args.max_steps)
    else:
        lr_scheduler = None

    if model_args.model_name_or_path:
        if not model_args.model_name_or_path == 'gpt2':
            logger.info(f"Loading Optimizer and Scheduler from checkpoint: {model_args.model_name_or_path}")
            ckpt = torch.load(os.path.join(model_args.model_name_or_path, 'optimizer.pt'))
            optimizer.load_state_dict(ckpt)
            ckpt = torch.load(os.path.join(model_args.model_name_or_path, 'scheduler.pt'))
            lr_scheduler = transformers.get_linear_schedule_with_warmup(optimizer, model_args.lr_warmup, training_args.max_steps)
            lr_scheduler.load_state_dict(ckpt)
        else:
            logger.info("Optimizer and Scheduler from start.")


    if data_args.block_size is None:
        block_size = tokenizer.model_max_length
        if block_size > 1024:
            logger.warn(
                f"The tokenizer picked seems to have a very large `model_max_length` ({tokenizer.model_max_length}). "
                "Picking 1024 instead. You can change that default value by passing --block_size xxx."
            )
        block_size = 1024
    else:
        if data_args.block_size > tokenizer.model_max_length:
            logger.warn(
                f"The block_size passed ({data_args.block_size}) is larger than the maximum length for the model"
                f"({tokenizer.model_max_length}). Using block_size={tokenizer.model_max_length}."
            )
        block_size = min(data_args.block_size, tokenizer.model_max_length)

    # Main data processing function that will concatenate all texts from our dataset and generate chunks of block_size.
    def group_texts(examples):
        # Concatenate all texts.
        concatenated_examples = {k: sum(examples[k], []) for k in examples.keys()}
        total_length = len(concatenated_examples[list(examples.keys())[0]])
        # We drop the small remainder, we could add padding if the model supported it instead of this drop, you can
        # customize this part to your needs.
        total_length = (total_length // block_size) * block_size
        # Split by chunks of max_len.
        result = {
            k: [t[i : i + block_size] for i in range(0, total_length, block_size)]
            for k, t in concatenated_examples.items()
        }
        result["labels"] = result["input_ids"].copy()
        return result

    # Note that with `batched=True`, this map processes 1,000 texts together, so group_texts throws away a remainder
    # for each of those groups of 1,000 texts. You can adjust that batch_size here but a higher value might be slower
    # to preprocess.
    #
    # To speed up this part, we use multiprocessing. See the documentation of the map method for more information:
    # https://huggingface.co/docs/datasets/package_reference/main_classes.html#datasets.Dataset.map
    if training_args.do_train:
        # data_ag_t = data_ag_t.shuffle() #never used before.
        lm_dataset_train = data_ag_t.map(
            group_texts,
            batched=True,
            num_proc=data_args.preprocessing_num_workers,
            load_from_cache_file=not data_args.overwrite_cache,
        )
    if training_args.do_eval:
        lm_dataset_eval = data_ag_v.map(
            group_texts,
            batched=True,
            num_proc=data_args.preprocessing_num_workers,
            load_from_cache_file=not data_args.overwrite_cache,
        )



    #model param count - for logging
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'The model has a total of {total_params}  parameters with {trainable_params} trainable paramets.')


    #different approach to freezing
    if model_args.freeze:
        model = freeze(model, config)


    # Initialize our Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=lm_dataset_train if training_args.do_train else None,
        eval_dataset=lm_dataset_eval if training_args.do_eval else None,
        tokenizer=tokenizer,
        # Data collator will default to DataCollatorWithPadding, so we change it.
        data_collator=default_data_collator,
        deepspeed='utils/deepspeed_config.json',
        optimizers=(optimizer, lr_scheduler),
    )

    # Training
    if training_args.do_train:
        model_path = (
            model_args.model_name_or_path
            if (model_args.model_name_or_path is not None and os.path.isdir(model_args.model_name_or_path))
            else None
        )
        train_result = trainer.train(model_path=model_path)
        trainer.save_model()  # Saves the tokenizer too for easy upload

        output_train_file = os.path.join(training_args.output_dir, "train_results.txt")
        if trainer.is_world_process_zero():
            with open(output_train_file, "w") as writer:
                logger.info("***** Train results *****")
                for key, value in sorted(train_result.metrics.items()):
                    logger.info(f"  {key} = {value}")
                    writer.write(f"{key} = {value}\n")

            # Need to save the state, since Trainer.save_model saves only the tokenizer with the model
            trainer.state.save_to_json(os.path.join(training_args.output_dir, "trainer_state.json"))

    # Evaluation
    results = {}
    if training_args.do_eval:
        logger.info("*** Evaluate ***")

        eval_output = trainer.evaluate()

        perplexity = math.exp(eval_output["eval_loss"])
        results["eval_loss"] = eval_output["eval_loss"]
        results["perplexity"] = perplexity

        output_eval_file = os.path.join(training_args.output_dir, "eval_results_clm.txt")
        if trainer.is_world_process_zero():
            with open(output_eval_file, "w") as writer:
                logger.info("***** Eval results *****")
                for key, value in sorted(results.items()):
                    logger.info(f"  {key} = {value}")
                    writer.write(f"{key} = {value}\n")

    return results


def _mp_fn(index):
    # For xla_spawn (TPUs)
    main()


if __name__ == "__main__":
    main()